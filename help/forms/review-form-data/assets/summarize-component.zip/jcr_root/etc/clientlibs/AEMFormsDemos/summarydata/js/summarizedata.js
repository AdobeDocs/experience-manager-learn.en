function determineFieldsToShow()
{

	guideBridge.visit(function(cmp)
 		{

  					if( (cmp.msClassName === "guidePanel")  && ( cmp.visible) ) 
    						{
            					console.log("Got Guide Panel");
         						var panelChildren = cmp.children;
            					if(cmp.name != "Summary")
            						{
		        	        			var existingDiv = document.getElementById(cmp.name);
        		    	    			if(existingDiv!=null)
                							{
												existingDiv.remove();
                							}
                					var table = document.createElement('table');
                					table.setAttribute('id',"tbl"+cmp.name);
                				var div = document.createElement('div');
                				div.setAttribute("id",cmp.name);
                				var headingTitle = "<h2>"+cmp.title+"</h2>";
                				div.innerHTML = headingTitle;
                				div.append(table);
                				$("#tblFormData").append(div);
         						for(var i=0;i<panelChildren.length;i++)
             						{

                    					if(cmp.children[i].className == "guideTable")
                    						{
                        						console.log("Bingo got table");

												$("#tbl"+cmp.name).append(createTable(cmp.children[1]));
                    						}
										if(panelChildren[i].visible)
                    						{

					 							var fieldValue = panelChildren[i].value;
                    							if (fieldValue === null)
                    								{
                        								fieldValue = 'No Value Provided';
                    								}
                    						if(fieldValue !== undefined)
                    								{
                    									var markup = "<tr><td>" + panelChildren[i].title + "</td><td >" + fieldValue + "</td><td id="+panelChildren[i].somExpression+"><button style = 'border-style:none;' class='editbutton' type='button'><i class='fa fa-pencil-square-o fa-2x'></i></button></td></tr>";
            											$("#tbl"+cmp.name).append(markup);
                        							}
                        					}


             	}
            }


    }


    });


}
$(document).ready(function()
  { 
    // set the focus to the form field for editing its value
    $(document).on("click","td",  function()
     {

         	 if($( this ).attr('id')!=null)
          		{
      				guideBridge.setFocus($( this ).attr('id'),"firstItem",false);
          		}
   });
guideBridge.on("elementNavigationChanged", function (event, payload)
    {

          determineFieldsToShow();
	});
 });


function createTable(tableCmp)
{
    console.log("@@@@ got table "+tableCmp.title);
    for(var j=0;j<tableCmp.children[3].children.length;j++)
    {
        console.log("@@@@@ The column name is "+tableCmp.children[3].children[j].title);
    }
        var tr = "<tr><td>Asset Type</td><td>Amount in Dollars</td></tr>";
        var tr1 = "<tr>";

        for(var k=0;k<tableCmp.children[2].instanceCount;k++)
        {
            var currentInstance = tableCmp.children[2].instances[k];



            for(var l=0;l< currentInstance.children.length;l++)
                {	

					var currChild = currentInstance.children[l];
                    	console.log("The asset type is  "+ currChild.value);
                    if(currChild.value!=null)
                    	{  
                    		tr1 = tr1+"<td>"+currChild.value+"</td>";
                    		if(l == currentInstance.children.length -1)
                    			{
                        			tr1 = tr1+"<td id="+currChild.somExpression+"><button style = 'border-style:none;' class='editbutton' type='button'><i class='fa fa-pencil-square-o fa-2x'></i></button></td></tr>";
                        			console.log("$$$$"+tr1);
                    			}
                        }



                }

        }
       console.log(tr+tr1);
    return tr1;
}








