$(document).ready(function(){

     $(".downloadPDF").click(function(){
         console.log("Download NewsLetters Clicked");
         var newslettersselectedfield = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].panel1672830811738[0].newslettersselected[0]");
         console.log(newslettersselectedfield.value);
         $.ajax({
   					url: '/bin/assemblenewsletter',
   					type: 'post',
   					data: {selectedNewsLetters:newslettersselectedfield.value},
   					success: function(response){
                        window.open(location.protocol+"//"+location.hostname+":"+location.port+response.assetPath);

   					}
				});
     });

});