
/**
* Populate drop down/choice group  with assets from specified folder
* @return {string[]} 
 */
function getDAMFolderAssets(damFolder)
{
    // strUrl is whatever URL you need to call
  var strUrl = '/bin/listfoldercontents?damFolder='+damFolder;
    var documents = [];

  $.ajax({
    url: strUrl,
    success: function(jsonData) {


       for(i=0;i<jsonData.length;i++)
            {
				documents.push(jsonData[i].assetpath+"="+jsonData[i].assetname);
            }

    },
    async:false
  });

  return documents;
}






