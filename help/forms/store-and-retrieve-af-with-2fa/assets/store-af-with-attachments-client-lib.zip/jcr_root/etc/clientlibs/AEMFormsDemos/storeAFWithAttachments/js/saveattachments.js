/**
* StoreFilesWithData
* @return {OPTIONS} drop down options 
 */
function StoreFilesWithData()
{

    guideBridge.getFormDataString({
      success: function (data) {
        var map = guideBridge._getFileAttachmentMapForSubmit();
          debugger;
          var tel = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].contactInformation[0].basicContact[0].telephoneNumber[0]");
       		var telephoneNumber = tel.value;

        guideBridge.doAjaxSubmitWithFileAttachment(
          "/bin/storeafdatawithattachments",
          {
            formData: data.data,
            fileMap: map,
             mobileNumber:telephoneNumber

          },
          {
            success: function (response) {
				console.log(response);
                 var blobid = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].contactInformation[0].basicContact[0].spouseDetails[0].guid[0]");
                blobid.value = response.applicationID;
            },
          },
          guideBridge._getFileAttachmentsList()
        );
      },
    });

}

