export default function ActivityName({formData,setFormData,page,setPage}){
  const frmSRC = formData.widgetURL;
  if(frmSRC)
    {
        //return(<div>No iframe yet</div>)
        return null;

    }  
  return (

      <div className="card">
        <p>What activity is this Waiver and Release of Liability being created for?</p>
        <div className="step-title"></div> 
        <input
          type="text"
          placeholder="Activity Name"
          value={formData.activity}
          onChange={(e) =>
            setFormData({...formData,activity:e.target.value})
          }
          className="form-group"
        />
        
        <button onClick={()=>{
          setPage(page +1);

        }}>
          Next
        </button>
        <br/>
       
      
      </div>
    );
  };
  
  
  