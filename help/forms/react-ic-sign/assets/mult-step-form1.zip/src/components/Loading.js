export default function Loading({spinner,setSpinner}){
   if(spinner)
    {
        return(
                <div>
                    <h1>Loading.......</h1>
                </div>
              );
  }
  
  
}