export default function GetWidgetURL({formData}){
    const frmSRC = formData.widgetURL;

    const minHeight = "500px";
    const minWidth = "500px";
    if(!frmSRC)
    {
        //return(<div>No iframe yet</div>)
        return null;

    }
    return(
        <div>
        <iFrame src={frmSRC} width={1900} height={1000} align={"center"} ></iFrame>
    </div>

    );
  };
  
  
  