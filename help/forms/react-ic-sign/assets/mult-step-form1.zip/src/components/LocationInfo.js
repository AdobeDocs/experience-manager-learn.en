export default function LocationInfo({formData,setFormData,page,setPage}){
    return (
      <div className="card">
        <p>What is the address of the party/organization being released from liability?</p>
        <div className="step-title"></div>
        <input
          type="text"
          placeholder="Address"
          value={formData.partyaddress}
          onChange={(e) =>
            setFormData({...formData,partyaddress:e.target.value})
          }
        />
        <input
          type="text"
          placeholder="City"
          value={formData.partycity}
          onChange={(e) =>
            setFormData({...formData,partycity:e.target.value})
          }
        />
         <input
          type="text"
          placeholder="State"
          value={formData.partystate}
          onChange={(e) =>
            setFormData({...formData,partystate:e.target.value})
          }
        />
        <input
          type="text"
          placeholder="Zipcode"
          value={formData.partyzip}
          onChange={(e) =>
            setFormData({...formData,partyzip:e.target.value})
          }
        />
  
  <button onClick={()=>{
          setPage(page+1);
        }}>
          Next
        </button>
        <br />
        <button onClick={()=>{
          setPage(page-1);
        }}>
          Previous
        </button>
        
      </div>
    );
  };