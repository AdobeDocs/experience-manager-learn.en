export default function PersonalInfo({formData,setFormData,page,setPage}) {
    return (
      <div className="card">
        <p>Who is the person participating in the activity?</p>
        <div className="step-title"></div>
        <input
          type="text"
          placeholder="Participant Name"
          value={formData.activityperson}
          onChange={(e) =>
            setFormData({...formData,activityperson:e.target.value})
          }
          
        />
        <input
          type="text"
          placeholder="Person Address"
          value={formData.personaddress}
          onChange={(e) =>
            setFormData({...formData,personaddress:e.target.value})
          }
          
          
        />
        <input
          type="text"
          placeholder="City"
          value={formData.personcity}
          onChange={(e) =>
            setFormData({...formData,personcity:e.target.value})
          }
          
          

        />
        <input
          type="text"
          placeholder="State"
          value={formData.personstate}
          onChange={(e) =>
            setFormData({...formData,personstate:e.target.value})
          }
         
          
          
          
        />
        <input
          type="text"
          placeholder="Zip"
          value={formData.personzip}
          onChange={(e) =>
            setFormData({...formData,personzip:e.target.value})
          }
         
          
        />
        <button onClick={()=>{
          setPage(page+1);
        }}>
          Next
        </button>
        <br/>
        <button onClick={()=>{
          setPage(page-1);
        }}>
          Previous
        </button>
      </div>
    );
  };
  