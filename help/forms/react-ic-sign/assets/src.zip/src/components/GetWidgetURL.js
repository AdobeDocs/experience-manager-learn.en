export default function GetWidgetURL({formData}){
    const frmSRC = formData.widgetURL;

    const minHeight = "500px";
    const minWidth = "500px";
    if(!frmSRC)
    {
        //return(<div>No iframe yet</div>)
        return null;

    }
    return(
        <div>
        <iFrame src={frmSRC} width={1600} height={800} align={"center"} ></iFrame>
    </div>

    );
  };
  
  
  