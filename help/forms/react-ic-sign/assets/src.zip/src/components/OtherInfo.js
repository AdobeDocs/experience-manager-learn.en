export default function OtherInfo({formData,setFormData,page,setPage}){
  const frmSRC = formData.widgetURL;
  if(frmSRC)
    {
        //return(<div>No iframe yet</div>)
        return null;

    }  

  const ww=async()=>
     {
        console.log("inside widgetURL function");
        let res = await fetch("http://enable1win.westus.cloudapp.azure.com:4503/bin/getwidgeturl",
          {
            method: "POST",
            body: JSON.stringify({"icTemplate":"/content/forms/af/waiver/waiver/channels/print","waiver":formData})
            
                
            
         })
         let myresp = await res.json();
         console.log("Got  JSON response!!!! "+myresp.widgetURL);
         setFormData({...formData,widgetURL:myresp.widgetURL})
        }
     
    return (
      <div className="card">
        <div className="step-title">Other Info</div>
        <input
          type="text"
          placeholder="Highest Qualification"
          onChange={(e) =>
            setFormData({...formData,highestQualification:e.target.value})
          }
        />
        <input
          type="text"
          placeholder="Occupation"
        />
        <textarea
          type="text"
          placeholder="About"
        />
        <br />
        <button onClick={()=>ww()}> 
          Submit
        </button>
        <br />
        <button>
          Previous
        </button>
      </div>
    );
  };