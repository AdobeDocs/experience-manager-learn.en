export default function ReceivingPartyName({formData,setFormData,page,setPage}){
    const frmSRC = formData.widgetURL;
    if(frmSRC)
      {
          //return(<div>No iframe yet</div>)
          return null;
  
      }  
  
    return (
      <div className="card">
        <p>What is the name of the party/organization being released from liability?</p>
        <div className="step-title"></div> 
        <input
          type="text"
          placeholder="Enter Party Name"
          value={formData.partyname}
          onChange={(e) =>
            setFormData({...formData,partyname:e.target.value})
          }
          className="form-group"
        />
        
        <button onClick={()=>{
          setPage(page +1);

        }}>
          Next
        </button>
        <br/>
        <button onClick={()=>{
          setPage(page - 1);

        }}>
          Previous
        </button>
        <br/>
       
      
      </div>
    );
  };
  
  
  