$(document).ready(function()
   {
       console.log("In add rows.js");
        const getFormNames = '/bin/getdrafts';
	$.getJSON(getFormNames, function (data) {
        var Row1 = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].drafts[0].Row1[0]");
       console.log(Row1.instanceManager.instanceCount);

        var jsonString = JSON.stringify(data);

        var jsonData = JSON.parse(jsonString);

        for(var i=0;i<jsonData.length;i++)
            {
                if(i == 0)
                   {

        				Row1.items[0].value = jsonData[i].draftName
      			 		Row1.items[1].value = jsonData[i].draftID;
                		Row1.items[2].value = jsonData[i].documentID;
            		}
        		else
        			{
                        var newInstance = Row1.instanceManager.addInstance();
        				newInstance.items[0].value = jsonData[i].draftName
      			 		newInstance.items[1].value = jsonData[i].draftID;
                		newInstance.items[2].value = jsonData[i].documentID;
        			}

            }

    });






   });
