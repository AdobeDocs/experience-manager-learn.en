 function dynamicEvent()
{

	    console.log($(this).attr('id'));
 		var getDataKeys = '/bin/getdatakeysfromschema?afName='+$(this).attr('id');
	    $.getJSON(getDataKeys, function (data) 
          {
            	var myFilters = new Array();
              var operatorsArray = new Array();
              operatorsArray.push("equal");
              operatorsArray.push("is_not_null");
              //myFilters.push({"operators":operatorsArray});
            	for(var i in data){
                if(data[i].details.hasOwnProperty("enum"))
    	               {
        		           	var values = data[i].values;
                	       myFilters.push({"operators":operatorsArray,"id":data[i].path,"input":data[i].input,"label":data[i].fieldName,"input":"select","values":data[i].details.enum});
	                   }
                	else
                		{

                            myFilters.push({"operators":operatorsArray,"id":data[i].path,"label":data[i].path.substring(2),"type":data[i].details.type});
                		}
        		}
              $("#builder").queryBuilder({
   			 filters: myFilters

			});

             
        });
 }



$(document).ready(function()

 {
     const getFormNames = '/bin/getformnames';
	$.getJSON(getFormNames, function (data) {
  	$.each(data, function (key, entry) {
       var divCard = document.createElement("div");
      	divCard.className = "cardcontent"
        divCard.innerHTML = entry.formName;
        divCard.id = entry.formPath;
        divCard.onclick = dynamicEvent; 
        $(".card").append(divCard);



     })
});

    $("#getsql").on('click', function ()
  	 {
    	var sqlob = $("#builder").queryBuilder("getSQL", false);
       	var sqlQuery = sqlob.sql;
    	console.log(sqlQuery);
       var columns = [];
    	$.getJSON('/bin/querydata?query='+sqlQuery, function (data) 
        	{
            	for(var i=0;i<data.columns.length;i++)
            		{
                		console.log("The column name is "+data.columns[i].data);
                		columns.push(data.columns[i]);
            		}
                   $('#example').DataTable( {
					data: data.data,
					columns: columns
					});
		});

});

});