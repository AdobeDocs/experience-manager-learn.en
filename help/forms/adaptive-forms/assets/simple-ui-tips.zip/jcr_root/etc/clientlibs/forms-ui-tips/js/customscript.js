$(document).ready(function()
{
    $( ".ssnField" ).append( "<p id='fisheye' style='color: Dodgerblue';><i class='fa fa-eye'></i></p>");

    $(document).on('click', 'p' , function() {
        var type = $(".ssnField").find("input").attr("type");

        if(type == "text")
        {
			$(".ssnField").find("input").attr("type", "password");
        }

        if(type == "password")
        {
			$(".ssnField").find("input").attr("type", "text");
        }

        });



});