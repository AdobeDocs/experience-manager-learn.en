async function createFile(imageName){
  let response = await fetch('/content/dam/formsanddocuments/fieldinspection/images/'+imageName);
  let data = await response.blob();
    console.log(data);
  let metadata = {
    type: 'image/jpeg'
  };
  let file = new File([data], "test.jpg", metadata);
     let reader = new FileReader();
    reader.readAsDataURL(file);
     reader.onload = function() {
    console.log("finished reading ...."+reader.result);
    var base64Field = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].HeatingAndAir[0].base64String[0]");
	base64Field.value = reader.result.substring(23);
  };
    var image  = new Image();
    $(".photo-upload .preview .imageP").remove();
    $(".photo-upload .preview .text").remove();
    image.width = 484;image.height = 334;
    image.className = "imageP";
    image.addEventListener("load", function () {
      $(".photo-upload .preview")[0].prepend(this);
    });
    //var image = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].General[0].rightPanel[0].partImage[0]");
	console.log(window.URL.createObjectURL(file));
    image.src = window.URL.createObjectURL(file);

  }
