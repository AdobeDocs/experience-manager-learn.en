/**
* Get pdf
* @return {OPTIONS} drop down options 
 */
function getPdf()
{
    console.log("in view pdf");
    window.guideBridge.getDataXML(
        {
        	success: function(result) {
             var formData = new FormData();
             formData.append("dataXml",result.data);
			console.log("got data"+result.data);
           	var settings ={
            				"async": true,
							"url": "/content/AemFormsSamples/getdor.html",
							"method": "POST",
                			data:{'data':result.data},
   						}
            $.ajax(settings).done(function(response)
            {
                console.log("got response");
                window.open(JSON.parse(response).filePath,'_blank');
            })

    	},
    	error:function(guideResultObject) {console.log("got error"); },
        guideState : null,
        boundData  : true});

}
