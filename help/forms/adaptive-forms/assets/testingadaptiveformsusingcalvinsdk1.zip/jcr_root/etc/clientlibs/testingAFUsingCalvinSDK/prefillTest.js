(function (window, hobs) {
    'use strict';

    var ts = new hobs.TestSuite("Prefill Test123", {
        path: '/etc/clientlibs/testingAFUsingCalvinSDK/prefillTest.js',
        register: false
    })

    .addTestCase(new hobs.TestCase("Prefill Test")
        // navigate to the testForm which is to be test
        .navigateTo("/content/forms/af/cal/demoform.html?wcmmode=disabled&dataRef=crx:///content/forms/af/cal/prefill.xml")
        // check if adaptive form is loaded
        .asserts.isTrue(function () {
            return calvin.isFormLoaded()
        })
        .asserts.isTrue(function () {
            return calvin.model("panel2.panel1488218690733.downPayment").value == 500;
        })
        .asserts.isTrue(function () {
            return calvin.model("GeneralInformation.USER_ID").value == 1;
        })
    );


    

}(window, window.hobs));
