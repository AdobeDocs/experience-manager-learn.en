(function(window, hobs) {
    'use strict';
    window.testsuites = window.testsuites || {};
 	// Registering the test form suite to the sytem
 	// If there are other forms, all registration should be done here
    window.testsuites.mortgageForm = new hobs.TestSuite("Test - Mortgage Form", {
        path: '/etc/clientlibs/calvinSDKTesting/init.js',
        register: true
    })
    window.testsuites.testForm = new hobs.TestSuite("Adaptive Form - Demo Test", {
        path: '/etc/clientlibs/calvinSDKTesting/init.js',
        register: true
    });
	// window.testsuites.testForm1 = new hobs.TestSuite("testForm1");
}(window, window.hobs));
