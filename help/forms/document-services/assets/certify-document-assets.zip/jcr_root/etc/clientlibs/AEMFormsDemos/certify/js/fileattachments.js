
$(document).ready(function()
   {
      guideBridge.on("elementValueChanged",function(event,data){
             if(data.target.name=="fileAttachment")
         {
             window.guideBridge.getFileAttachmentsInfo({
     			success:function(list) 
                 {
                     console.log(list[0].name + " "+ list[0].path);
                     var pdfpathfield = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].attachmentpath[0]");
						pdfpathfield.value = list[0].path;
                     var submitButton = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].submitform[0]");
                     submitButton.visible = true
                      }
             });
         }
        });

});