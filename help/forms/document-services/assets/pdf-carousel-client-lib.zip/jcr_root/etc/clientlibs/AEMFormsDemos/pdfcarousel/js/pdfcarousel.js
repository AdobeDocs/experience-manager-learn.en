
$(document).ready(function() 
    { 
        var pdfdocumentsarray = document.querySelector("[data-renderpdf]").getAttribute("data-renderpdf").split(",");
        console.log(pdfdocumentsarray[0]);
        console.log(pdfdocumentsarray[0].split("/")[5]);
        document.addEventListener("adobe_dc_view_sdk.ready", function()
    {
		var adobeDCView = new AdobeDC.View({clientId:  document.querySelector("[data-apikey]").getAttribute("data-apikey"),divId: "adobe-dc-view"});
       console.log("In preview file"+document.querySelector("[data-apikey]").getAttribute("data-apikey"));
        var len = pdfdocumentsarray[0].split("/").length;
       adobeDCView.previewFile
       (

       	{
            content:   {location: {url: pdfdocumentsarray[0]}},
          metaData: {fileName: pdfdocumentsarray[0].split("/")[len-1]}

       },
           {showAnnotationTools: false}
      );

        var adobeDCView1 = new AdobeDC.View({clientId:  document.querySelector("[data-apikey]").getAttribute("data-apikey"),divId: "adobe-dc-view2"});
       var len1 = pdfdocumentsarray[1].split("/").length;
       adobeDCView1.previewFile
       (

       	{
          content:   {location: {url: pdfdocumentsarray[1]}},
          metaData: {fileName: pdfdocumentsarray[1].split("/")[len-1]}

       },
           {showAnnotationTools: false}
      );
      var adobeDCView2 = new AdobeDC.View({clientId:  document.querySelector("[data-apikey]").getAttribute("data-apikey"),divId: "adobe-dc-view1"});
       console.log("In preview file");
        var len2 = pdfdocumentsarray[2].split("/").length;
       adobeDCView2.previewFile
       (

       	{
            content:   {location: {url: pdfdocumentsarray[2]}},
          metaData: {fileName: pdfdocumentsarray[2].split("/")[len-1]}

       },
           {showAnnotationTools: false}
      );
    });


       });



