function createPDF(formData,status)
{
        $.ajax({
            type:'POST',
            data:formData,
            url:'/content/AemFormsSamples/pdfg.html',
            contentType:false,
        	processData: false,
        	cache: false,
            success:function(response)
            {
                console.log(JSON.parse(response));

  				 $("#status").hide();
                //$("#message").append(JSON.parse(response).message);
                $("#initial").append("<p>"+JSON.parse(response)[0].message);
                $("#initial").show();
           	}
        });
}
function handleFileUpload(files,obj)
{
   {
        var fd = new FormData();
        fd.append('file', files[0]);
		fd.append('fileName', files[0].name);
        createPDF(fd,status);

   }
}
$(document).ready(function()
   {
       $("#status").hide();
   	 var obj = $("#dragandrophandler");
	obj.on('dragenter', function (e) 
		{
    		e.stopPropagation();
    		e.preventDefault();
    		$(this).css('border', '2px solid #0B85A1');
		});
	obj.on('dragover', function (e) 
		{
     		e.stopPropagation();
     		e.preventDefault();
		});
	obj.on('drop', function (e) 
		{
 		     	$(this).css('border', '2px dotted #0B85A1');
     			e.preventDefault();
     			var files = e.originalEvent.dataTransfer.files;
 			     //We need to send dropped files to Server
            	$("#initial").empty();
            	$("#initial").append(files[0].name);
            $("#initial").hide();
            	 $("#status").show();
     			handleFileUpload(files,obj);
		});
       $(document).on('dragenter', function (e) 
{
    e.stopPropagation();
    e.preventDefault();
});
$(document).on('dragover', function (e) 
{
  	e.stopPropagation();
  	e.preventDefault();
  obj.css('border', '2px dotted #0B85A1');
});
$(document).on('drop', function (e) 
{
    e.stopPropagation();
    e.preventDefault();
});


});