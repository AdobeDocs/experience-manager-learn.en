
$(document).ready(function() 
    { 
        $(".viewPDF").click(function()
       {
           console.log("view pdfclicked");


				window.guideBridge.getDataXML(
    	    		{
        				success: function(result)
            				{
	           	 				var formData = new FormData();

             					formData.append("data",result.data);
                                formData.append("template",document.querySelector("[data-template]").getAttribute("data-template"));
                				const fetchPromise1 = fetch(document.querySelector("[data-endpoint]").getAttribute("data-endpoint"),
                           			{
            							method: "POST",
                                        body:formData,
                                        contentType:false,
                                        processData:false,

        							}
        								)
                    						.then(response => {

																	var adobeDCView = new AdobeDC.View({clientId: document.querySelector("[data-apikey]").getAttribute("data-apikey"), divId: "adobe-dc-view"});
            														console.log("In preview file");
        															adobeDCView.previewFile
        																(

       																		{
                                                    							content: {promise:response.arrayBuffer()},
          																		metaData: {fileName: document.querySelector("[data-filename]").getAttribute("data-filename")}
       																		}
        																);


                  											console.log("done")
                            								})


            					}
        				});
       });


        	document.addEventListener("adobe_dc_view_sdk.ready", function()
    		{
        })
       });
    


