
function assembleFiles(formData)

{
     formData.append("saveLocation","c:\\scrap");
    for (var pair of formData.entries()) {
    console.log("the key is"+pair[0]+ ', ' + pair[1]); 

}

$.ajax({
         type:'POST',
         data:formData,
         url:'/bin/generatepdfbatch',
         contentType:false,
         processData: false,
    	dataType: 'json',
         cache: false,
         complete:function(){
         $("#frm").removeClass('is-uploading');
          },
    error:function(error)
    {
        console.log("got error");
    },
    complete:function(response)
    {
         $("#frm").removeClass('is-uploading');
    },
         success:function(response)
           {
             console.log(response);
                $("#status").append("<p><a href="+response.path+">Download file</a></p>");
             $("#frm").addClass('is-success');
           	}
        });
}
function handleFileUpload(files,obj)
{
	var fd = new FormData();
    fd.append("saveLocation","c:\\scrap");
    for (var i = 0; i < files.length; i++) 
   	{
	    fd.append('file', files[i]);
		fd.append('fileName', files[i].name);
        console.log("The file name added manualy is "+ files[i].name);
   	}
   for (var pair of fd.entries())
	{
 		console.log(pair[0]+ ', '+ pair[1]); 
	}
    assembleFiles(fd);

}
$(document).ready(function()
   {
         var droppedFiles = false;
       // if the files are seelcted manually
       $("input").on('change',function(e)
			{
                console.log("submitting files");
                var filesUploaded = e.target.files; 
                var ajaxData = new FormData($("#form").get(0));
                for(var i=0;i<filesUploaded.length;i++)
                  {
					ajaxData.append(filesUploaded[i].name, filesUploaded[i]);
                  }

                     assembleFiles(ajaxData);


			});


 $("#frm").on('drag dragstart dragend dragover dragenter dragleave drop', function(e)
   		{
     		console.log("in frm drop");
			e.preventDefault();
			e.stopPropagation();
  		});

$("#frm").on('submit',function(e)
    	{
       		e.preventDefault();
       		console.log("Submitting form");
       		if ($("#frm").hasClass('is-uploading')) return false;
	 		$("#frm").addClass('is-uploading').removeClass('is-error');
   			var ajaxData = new FormData($("#form").get(0));
     		if (droppedFiles)
        	 {
				$.each( droppedFiles, function(i, file)
             		{
						ajaxData.append(droppedFiles[i].name, file );
               			console.log("appended files");
					});
          		assembleFiles(ajaxData);
         	}
      	});
$("#frm").on('drop', function(e) 
		{
   			droppedFiles = e.originalEvent.dataTransfer.files;
        	e.preventDefault();
	    	$("#frm").trigger('submit');
		});
});