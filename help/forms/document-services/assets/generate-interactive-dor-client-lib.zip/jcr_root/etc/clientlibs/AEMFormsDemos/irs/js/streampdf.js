$(document).ready(function()
   {
     $(".downloadPDF").click(function()
       {
           window.guideBridge.getDataXML({
     			success:function(guideResultObject) 
                 {
            		var req = new XMLHttpRequest();

					req.open("POST", "/bin/generateinteractivedor", true);

					req.responseType = "blob";

                    var postParameters = new FormData();
             		postParameters.append("dataXml",guideResultObject.data);
                    postParameters.append("xdpName","f8918-r14e_redo-barcode_3 2.xdp");
                     //postParameters.append("xdpName","two.xdp")
                     postParameters.append("formBasedOnSchema","true");
                     //postParameters.append("xfaRootElement","form1");
                     postParameters.append("dataNodeToExtract","afData/afBoundData/topmostSubform");
                     console.log(guideResultObject.data);
					req.send(postParameters);
					req.onreadystatechange = function()
            			{

                            if(req.readyState == 4 && req.status == 200) 
            					{

                                      download(this.response, "report.pdf", "application/pdf");


    							}


						}
			         }
           });

       });
   });


