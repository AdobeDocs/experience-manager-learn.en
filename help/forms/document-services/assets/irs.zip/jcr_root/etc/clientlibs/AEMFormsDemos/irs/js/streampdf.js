$(document).ready(function()
   {
     $(".savebutton").click(function()
       {
           window.guideBridge.getDataXML({
     			success:function(guideResultObject) 
                 {
            		var req = new XMLHttpRequest();
                     
					req.open("POST", "/bin/generateinteractivedor", true);
					req.responseType = "blob";

                    var formData = new FormData();
             		formData.append("dataXml",guideResultObject.data);
                     console.log(guideResultObject.data);
					req.send(formData);

					req.onreadystatechange = function()
            			{

                            if(req.readyState == 4 && req.status == 200) 
            					{



                                      download(this.response, "report.pdf", "application/pdf");


    							}


						}
			         }
           });

       });
   });


