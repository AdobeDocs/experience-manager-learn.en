Text Component: Plain Text

```js
<Text  text="Plain text" />
```

Text Component: Rich text

```js
<Text richText="true" text="<h1>Hello</h1><p><b>Rich</b> Text</p>" />
```