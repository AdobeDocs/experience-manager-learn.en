Image:

```js
<Image  alt="Alternative Text here"
src="mock-image.jpeg"/>
```

Image with a caption:

```js
<Image  alt="Alternative Text here" title="This is a caption" 
src="mock-image.jpeg"/>
```