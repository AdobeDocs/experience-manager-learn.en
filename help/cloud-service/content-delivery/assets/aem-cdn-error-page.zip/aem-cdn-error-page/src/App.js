import logo from "./wknd-logo.png";
import "./App.css";

function App() {
  return (
    <>
      <div className="App">
        <div className="container">
        <img src={logo} className="App-logo" alt="logo" />
        </div>
      </div>
      <div className="container">
        <div className="error-code">CDN Error Page</div>
        <h1 className="error-message">Ruh-Roh! Page Not Found</h1>
        <p className="error-description">
          We're sorry, we are unable to fetch this page!
        </p>
      </div>
    </>
  );
}

export default App;
