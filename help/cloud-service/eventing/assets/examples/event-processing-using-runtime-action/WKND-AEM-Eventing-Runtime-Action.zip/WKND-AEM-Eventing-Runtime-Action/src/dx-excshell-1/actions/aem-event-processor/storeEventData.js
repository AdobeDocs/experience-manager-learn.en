/* eslint-disable max-len */
/* eslint-disable import/no-extraneous-dependencies */
const { Core } = require('@adobe/aio-sdk');
const filesLib = require('@adobe/aio-lib-files');

/**
 * This module stores the original AEM Event and Event Details loaded from Author Service in the database.
 * The database is a File System in this case, provided by the Adobe I/O Files SDK.
 *
 *
 * @param {*} activityMessage - the AEM Event as an activity message
 * @param {*} aemEvent - the original AEM Event
 * @param {*} aemEventDetails - the AEM Event Details loaded from AEM Author instance
 * @returns {object} - the file path, content length, URL and internal URL of the stored file
 */
async function storeEventData(activityMessage, aemEvent, aemEventDetails) {
  // create a Logger
  const logger = Core.Logger('storeEventData', {
    level: 'info',
  });

  logger.info('Storing AEM Event and Event Details in the database');

  // get the current date and format it as YYYY-MM-DD to be used as the folder name
  const date = new Date(aemEvent.getTime());
  const formattedDate = `${date.getFullYear()}-${(date.getMonth() + 1)
    .toString()
    .padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;

  const files = await filesLib.init();

  const eventDataAsJSON = JSON.stringify({
    activity: activityMessage,
    aemEvent,
    aemEventDetails,
  });

  // store details in a folder named YYYY-MM-DD and a file named <eventID>.json
  const bytesWritten = await files.write(
    `${formattedDate}/${aemEvent.getEventID()}.json`,
    eventDataAsJSON,
  );

  logger.info(
    `AEM Event and Event Details stored in the database, bytesWritten: ${bytesWritten}`,
  );

  // get the file properties
  const fileProps = await files.getProperties(
    `${formattedDate}/${aemEvent.getEventID()}.json`,
  );

  logger.info(`File properties: ${JSON.stringify(fileProps)}`);

  // return the file path, content length, URL and internal URL of the stored file
  return {
    filePath: fileProps.name,
    contentLength: fileProps.contentLength,
    url: fileProps.url,
    internalUrl: fileProps.internalUrl,
  };
}

module.exports = storeEventData;
