import {
  Cell,
  Column,
  ProgressCircle,
  Row,
  TableBody,
  TableHeader,
  TableView,
  Flex,
} from "@adobe/react-spectrum";
import React, { useEffect, useState } from "react";
import allActions from "../config.json";
import actionWebInvoke from "../utils";

/**
 *
 * React component that renders the CF Activity Details table by calling the `load-processed-aem-events` action.
 *
 */
export const CFActivityDetails = (props) => {
  const columns = [
    { name: "Event Date", uid: "date" },
    { name: "Event Name", uid: "event-name" },
    { name: "Event Activity", uid: "event-activity" },
    { name: "Event Details", uid: "event-details" },
  ];

  const [loading, setLoading] = useState(true);
  const [activityDetailsRows, setActivityDetailsRows] = useState([]);

  // load the CF Activity Details on component mount by calling the `load-processed-aem-events` action
  useEffect(() => {
    (async () => {
      loadCFActivityDetails();
    })();
  }, []);

  if (loading) {
    return showLoading();
  } else {
    return renderTable();
  }

  /**
   * Calls the `load-processed-aem-events` action to get the list of processed AEM Events.
   */
  async function loadCFActivityDetails() {
    console.log("Loading CF Activity Details...");

    setLoading(true);

    // set the params for the action
    const params = {};
    // set the authorization header and org from the ims props object
    const headers = {};
    if (props.props.ims.token && !headers.authorization) {
      headers.authorization = `Bearer ${props.props.ims.token}`;
    }
    if (props.props.ims.org && !headers["x-gw-ims-org-id"]) {
      headers["x-gw-ims-org-id"] = props.props.ims.org;
    }

    const actionName = "load-processed-aem-events";
    try {
      const actionResponse = await actionWebInvoke(
        allActions[actionName],
        headers,
        params
      );

      console.log("Action Response:", actionResponse);

      if (actionResponse.details && actionResponse.details.processedEvents) {
        const processedEvents = actionResponse.details.processedEvents;
        let rows = [];
        processedEvents.forEach((processedEvent) => {
          rows.push(toRowData(processedEvent));
        });

        console.log("Activity Details Rows:", rows.length);

        setActivityDetailsRows(rows);
      }
    } catch (e) {
      console.error(e);
    }

    // set loading to false
    setLoading(false);
  }

  /**
   *
   * Helper method to convert the processed event into a row object.
   *
   * @param {*} processedEvent - processed event object received from the action
   * @returns - row object with necessary fields for the table
   */
  function toRowData(processedEvent) {
    const row = {};

    row["id"] = processedEvent.aemEvent.event_id;

    // parse event name
    if (processedEvent.aemEvent.type) {
      const typeParts = processedEvent.aemEvent.type.split(".");
      if (typeParts.length === 4) {
        row["event-name"] =
          typeParts[2].charAt(0).toUpperCase() +
          typeParts[2].slice(1) +
          "-" +
          typeParts[3].charAt(0).toUpperCase() +
          typeParts[3].slice(1);
      } else {
        row["event-name"] = "Unknown";
      }
    }

    // parse activity message
    if (processedEvent.activity) {
      let activity = processedEvent.activity.replace(
        "/content/dam/wknd-shared/en",
        ""
      );
      row["event-activity"] = activity;
    }

    // convert date to local date time
    if (processedEvent.aemEvent.time) {
      let date = new Date(processedEvent.aemEvent.time);
      row["date"] = date.toLocaleDateString() + " " + date.toLocaleTimeString();
    }

    // construct event details message
    if (
      processedEvent.aemEventDetails &&
      processedEvent.aemEventDetails.length > 0
    ) {
      let detailsMsg = "";
      processedEvent.aemEventDetails.forEach((aemEventDetail) => {
        detailsMsg =
          detailsMsg +
          ` Updated ${aemEventDetail.value.title} (${aemEventDetail.key}) to ${aemEventDetail.value.value},`;
      });
      row["event-details"] = detailsMsg.slice(0, -1);
    }

    return row;
  }

  /**
   *
   * Renders the CF Activity Details table.
   */
  function renderTable() {
    console.log(
      `Rendering table..., columns: ${columns}, rows: ${activityDetailsRows.length}`
    );
    return (
      <>
        <TableView flex overflowMode="wrap" aria-label="CF Activity Details">
          <TableHeader columns={columns}>
            {(column) => <Column key={column.uid}>{column.name}</Column>}
          </TableHeader>
          <TableBody items={activityDetailsRows}>
            {(item) => (
              <Row>{(columnKey) => <Cell>{item[columnKey]}</Cell>}</Row>
            )}
          </TableBody>
        </TableView>
      </>
    );
  }

  /**
   *
   * Renders the loading indicator.
   */
  function showLoading() {
    return (
      <>
        <Flex alignItems="center" justifyContent="center" height="50vh">
          <ProgressCircle
            size="L"
            aria-label="Loading…"
            justifySelf={"center"}
            isIndeterminate
          />
        </Flex>
      </>
    );
  }
};
