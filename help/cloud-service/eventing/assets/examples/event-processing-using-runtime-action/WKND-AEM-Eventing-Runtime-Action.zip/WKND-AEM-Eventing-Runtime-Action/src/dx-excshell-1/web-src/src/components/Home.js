/*
 * <license header>
 */

import React from "react";
import { Grid, View, Heading, Text, Icon } from "@adobe/react-spectrum";
import { CFActivityDetails } from "./CFActivityDetails";

/**
 *
 * React component that renders the Home page.
 *
 */
export const Home = (props) => (
  <Grid
    areas={["header  header", "content content", "footer  footer"]}
    columns={["1fr", "3fr"]}
    rows={["size-1000", "auto", "size-1000"]}
    height="auto"
    gap="size-100"
  >
    <View
      backgroundColor=""
      gridArea="header"
      alignSelf={"center"}
      justifySelf={"center"}
    >
      <Heading level={1}>
        AEM Eventing - WKND Demo - Content Fragment Event Activity Details
      </Heading>
    </View>

    <View
      backgroundColor=""
      gridArea="content"
    >
      <CFActivityDetails props={props} />
    </View>

    <View
      backgroundColor=""
      gridArea="footer"
      alignSelf={"center"}
      justifySelf={"center"}
    >
      <Text
        UNSAFE_style={{
          color: "white",
          alignContent: "center",
          margin: ".5rem 0 0 0",
          fontStyle: "italic",
          fontSize: ".75rem",
        }}
      >
      </Text>
    </View>
  </Grid>
);
