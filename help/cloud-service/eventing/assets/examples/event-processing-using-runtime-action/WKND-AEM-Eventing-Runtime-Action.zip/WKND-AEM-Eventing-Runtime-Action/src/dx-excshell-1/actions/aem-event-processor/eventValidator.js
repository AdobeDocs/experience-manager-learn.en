const { Core } = require('@adobe/aio-sdk');

/**
 * This module determines if the event should be processed by calling the AEM Author service
 * For demo purposes, only Content Fragment Modified events require callback to AEM Author service.
 *
 * @param {*} aemEvent - the AEM Event to be checked
 * @returns {boolean} - true if callback to AEM Author service is required, false otherwise
 */
async function needsAEMCallback(aemEvent) {
  // create a Logger
  const logger = Core.Logger('eventValidator', {
    level: 'info',
  });

  let isValid = false;

  // verify the event is a Content Fragment Modified event
  if (
    aemEvent
    && aemEvent.ContentType === 'contentFragment'
    && aemEvent.EventName === 'modified'
  ) {
    logger.info('Processing Content Fragment Modified Event');
    isValid = true;
  }

  return isValid;
}

module.exports = needsAEMCallback;
