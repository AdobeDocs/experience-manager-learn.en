/* eslint-disable consistent-return */
/* eslint-disable max-len */
/*
 * <license header>
 */

const { Core } = require('@adobe/aio-sdk');
const {
  errorResponse,
  stringParameters,
  checkMissingRequestInputs,
} = require('../utils');

const AEMEvent = require('../model/aemEvent');
const needsAEMCallback = require('./eventValidator');
const loadEventDetailsFromAEMAuthorService = require('./loadEventDetailsFromAEM');

const storeEventData = require('./storeEventData');
const { InvalidEventPayload, AEMConnectionError } = require('../model/errors');

/**
 * This `aem-event-processor` action receives an AEM Event from Adobe I/O Events.
 *
 * - First it creates an AEM Event object from the request parameters. The AEM Event provides helper methods.
 * - Then using following modules it performs the following tasks:
 *    - `eventValidator.js` - to determine if the event should be processed by calling the AEM Author service
 *    - `loadEventDetailsFromAEM.js` - to call the AEM Author service to get specifics about the event
 *    - `storeEventData.js` - to store the event and event details in the file system provided by the Adobe I/O Runtime action
 *
 * #########################################################
 *
 * In real world scenarios, possible next steps would be:
 * - Notify (email, chat, API call,  etc) other services about the content change.
 * - Callback to AEM Author or Publish service to get more details about the event or new content.
 *   Or even update the content in AEM Author service.
 * - Using the callback details (event or new content), call other services to perform additional actions
 *   like update related content, cache invalidation, social media updates, etc.
 *
 * Essentially, the action is the entry point to a business process that can be as simple or complex as needed.
 *
 * #########################################################

 * @param {*} params - Adobe I/O Runtime action parameters
 * @returns {object} - returns success or failure response
 */
async function main(params) {
  // create a Logger
  const logger = Core.Logger('main', { level: params.LOG_LEVEL || 'info' });

  try {
    // 'info' is the default level if not set
    logger.info('Calling the AEM Event Processor action');

    // log parameters, only if params.LOG_LEVEL === 'debug'
    logger.debug(stringParameters(params));

    // check for missing request input parameters and headers
    const requiredParams = ['id'];
    const requiredHeaders = [];
    const errorMessage = checkMissingRequestInputs(
      params,
      requiredParams,
      requiredHeaders,
    );

    if (errorMessage) {
      // return and log client errors
      return errorResponse(400, errorMessage, logger);
    }

    let responseMsg;

    // handle the challenge probe request, they are sent by I/O to verify the action is valid
    if (params.challenge) {
      logger.info('Challenge probe request detected');
      responseMsg = JSON.stringify({ challenge: params.challenge });
    } else {
      logger.info('AEM Event request received');

      // create AEM Event object from request parameters
      const aemEvent = new AEMEvent(params);

      // get AEM Event as activity message using the helper method
      const activityMessage = aemEvent.getEventAsActivityMessage();

      // determine if AEM Event requires callback to AEM Author service
      const callbackAEMForEventDetails = await needsAEMCallback(aemEvent);

      let eventDetails = {};
      if (callbackAEMForEventDetails) {
        // call AEM Author service to get specifics about the event
        eventDetails = await loadEventDetailsFromAEMAuthorService(
          aemEvent,
          params,
        );
      }

      // store AEM Event and Event details in the file system
      const storageDetails = await storeEventData(
        activityMessage,
        aemEvent,
        eventDetails || {},
      );
      logger.info(`Storage details: ${JSON.stringify(storageDetails)}`);

      // create response message
      responseMsg = JSON.stringify({
        message: 'AEM Event processed',
        activityMessage,
      });

      // response object
      const response = {
        statusCode: 200,
        body: responseMsg,
      };
      logger.info('Adobe I/O Runtime action response', response);

      // Return the response to the caller
      return response;
    }
  } catch (error) {
    // AEMEvent constructor throws InvalidEventPayload
    if (error instanceof InvalidEventPayload) {
      logger.error(error);
      return errorResponse(400, error.message, logger);
    }

    // AEMConnectionError is thrown by loadEventDetailsFromAEM
    if (error instanceof AEMConnectionError) {
      logger.error(error);
      return errorResponse(500, error.message, logger);
    }
    // log any server errors
    logger.error(error);
    // return with 500
    return errorResponse(500, 'server error', logger);
  }
}

exports.main = main;
