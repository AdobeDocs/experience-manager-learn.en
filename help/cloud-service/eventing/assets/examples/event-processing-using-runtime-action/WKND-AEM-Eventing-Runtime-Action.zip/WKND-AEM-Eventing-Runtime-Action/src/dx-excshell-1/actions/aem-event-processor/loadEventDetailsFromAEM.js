/* eslint-disable camelcase */
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable max-len */
const { Core } = require('@adobe/aio-sdk');
const auth = require('@adobe/jwt-auth');
const { AEMConnectionError } = require('../model/errors');

/**
 * This module loads the details of the AEM Event from AEM Author instance.
 * In this case, it loads the values of the Content Fragment properties that were added or modified.
 *
 * @param {*} aemEvent  - the AEM Event whose details need to be loaded
 * @param {*} params - the params object via Adobe I/O Runtime Action
 * @returns {object} - the new values of the CF properties that were added or modified
 */
async function loadEventDetailsFromAEMAuthorService(aemEvent, params) {
  // create a Logger
  const logger = Core.Logger('loadEventDetailsFromAEM', {
    level: 'info',
  });

  // event value is "aem-p63947-e1249010", so replace "aem" with "author" and add ".adobeaemcloud.com"
  const aemAuthorHost = `https://${aemEvent
    .getAEMHost()
    .replace('aem', 'author')}.adobeaemcloud.com`;
  const cfPath = aemEvent.getContentPath();

  // From AEM Event get the names of the CF properties that were added or modified
  const cfPropertiesAddedOrModified = [];
  aemEvent.getProperties().forEach((property) => {
    if (property.changeType === 'modified' || property.changeType === 'added') {
      cfPropertiesAddedOrModified.push(property.name);
    }
  });

  logger.info(
    `Loading AEM Event Details from AEM Author instance, looking for ${cfPropertiesAddedOrModified.join(
      ', ',
    )}`,
  );

  // Get AEM Service Credentials aka Technical Account details.
  // These are passed to the action as params and added in .env file.
  const clientId = params.AEM_SERVICECREDENTIALS_TECHNICALACCOUNT_CLIENTID;
  const technicalAccountId = params.AEM_SERVICECREDENTIALS_ID;
  const orgId = params.AEM_SERVICECREDENTIALS_ORG;
  const clientSecret = params.AEM_SERVICECREDENTIALS_TECHNICALACCOUNT_CLIENTSECRET;
  // Private key is passed as a string with \n and \r characters escaped.
  const privateKey = params.AEM_SERVICECREDENTIALS_PRIVATEKEY.replace(
    /\\n/g,
    '\n',
  ).replace(/\\r/g, '\r');
  const metaScopes = params.AEM_SERVICECREDENTIALS_METASCOPES.split(',');
  const ims = `https://${params.AEM_SERVICECREDENTIALS_IMSENDPOINT}`;

  // Get the access token from IMS using Adobe I/O SDK
  const { access_token } = await auth({
    clientId,
    technicalAccountId,
    orgId,
    clientSecret,
    privateKey,
    metaScopes,
    ims,
  });

  /**
   * Uncomment for debugging purposes
  logger.info(
    `clientId: ${clientId}, technicalAccountId: ${technicalAccountId}, orgId: ${orgId}, clientSecret: ${clientSecret}, privateKey: ${privateKey}, metaScopes: ${metaScopes}, ims: ${ims}`,
  );
  logger.info(`Access token retrieved from IMS successfully:\n${access_token}`);
  */

  // Call AEM Author service to get the CF details using AEM Assets API
  const res = await fetch(
    `${aemAuthorHost}${cfPath.replace('/content/dam/', '/api/assets/')}.json`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${access_token}`,
      },
    },
  );

  let newValuesOfCFPropertiesAddedOrModified = {};
  // If the response is OK, get the values of the CF properties that were added or modified
  if (res.ok) {
    logger.info('AEM Event Details loaded from AEM Author instance');
    const responseJSON = await res.json();

    // Get the values of the CF properties that were added or modified
    if (
      responseJSON
      && responseJSON.properties
      && responseJSON.properties.elements
    ) {
      const allCurrentCFProperties = responseJSON.properties.elements;

      newValuesOfCFPropertiesAddedOrModified = cfPropertiesAddedOrModified.map(
        (key) => ({
          key,
          value: allCurrentCFProperties[key],
        }),
      );
    } else {
      logger.info(
        'No properties found in AEM Event Details loaded from AEM Author instance',
      );
    }
  } else {
    // If the response is not OK, throw an error
    logger.error(
      `Error loading AEM Event Details from AEM Author instance, status code: ${
        res.status
      }, status text: ${res.statusText}, body: ${await res.text()}`,
    );
    throw new AEMConnectionError(`Could not connect to ${aemAuthorHost}`);
  }

  return newValuesOfCFPropertiesAddedOrModified;
}

module.exports = loadEventDetailsFromAEMAuthorService;
