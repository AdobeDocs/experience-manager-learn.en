/* eslint-disable max-len */
/*
 * <license header>
 */

const { Core } = require('@adobe/aio-sdk');
const filesLib = require('@adobe/aio-lib-files');
const {
  errorResponse,
  stringParameters,
  checkMissingRequestInputs,
} = require('../utils');

/**
 *
 *  This `load-processed-aem-events` action returns the list of processed AEM Events. They are rendered in the UI.
 *
 * - It reads the processed events, another `aem-event-processor` action stores them.
 * - For demo purposes, it only returns the first 20 events.
 *
 * #########################################################
 *
 * In real world scenarios, you don't need this action or the UI.
 *
 * #########################################################
 *
 * @param {*} params
 * @returns
 */
async function main(params) {
  // create a Logger
  const logger = Core.Logger('main', { level: params.LOG_LEVEL || 'info' });

  try {
    // 'info' is the default level if not set
    logger.info('Calling the main action');

    // log parameters, only if params.LOG_LEVEL === 'debug'
    logger.debug(stringParameters(params));

    // check for missing request input parameters and headers
    const requiredParams = [];
    const requiredHeaders = ['Authorization'];
    const errorMessage = checkMissingRequestInputs(
      params,
      requiredParams,
      requiredHeaders,
    );
    if (errorMessage) {
      // return and log client errors
      return errorResponse(400, errorMessage, logger);
    }

    const files = await filesLib.init();
    const allFiles = await files.list('/');
    logger.info(`Files found: ${allFiles.length}`);

    // for demo purposes, only return the first 20 files
    const filePaths = allFiles.slice(0, 20);

    const processedEvents = [];

    await Promise.all(
      filePaths.map(async (filePath) => {
        logger.info(`Processing file: ${filePath}`);
        const buffer = await files.read(filePath.name);
        const myEventData = buffer.toString();
        logger.info(`File: ${filePath.name}, content: ${myEventData}`);

        processedEvents.push(JSON.parse(myEventData));
      }),
    );

    const response = {
      statusCode: 200,
      body: JSON.stringify({ msg: 'success', details: { processedEvents } }),
    };

    // log the response status code
    logger.info(
      `${response.statusCode} & ${response.body}: successful request`,
    );
    return response;
  } catch (error) {
    // log any server errors
    logger.error(error);
    // return with 500
    return errorResponse(500, 'server error', logger);
  }
}

exports.main = main;
