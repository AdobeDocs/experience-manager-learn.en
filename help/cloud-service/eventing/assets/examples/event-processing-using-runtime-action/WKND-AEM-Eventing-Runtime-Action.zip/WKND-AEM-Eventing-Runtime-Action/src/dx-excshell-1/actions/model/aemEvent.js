/* eslint-disable prefer-destructuring */
/* eslint-disable no-use-before-define */
/* eslint-disable no-unused-vars */

const { InvalidEventPayload } = require('./errors');

/**
 * AEM Event model class, used to parse AEM Event data and provide helper methods
 *
 * @class AEMEvent
 * @param {object} params - params object via Adobe I/O Runtime Action
 *
 */
class AEMEvent {
  constructor(params) {
    // Validate the params, make sure we have the required properties
    if (params === undefined && params.data === undefined && params.data.user === undefined) {
      throw new InvalidEventPayload('Invalid AEM Event payload');
    }

    this.source = params.source;
    this.data = params.data;
    this.id = params.id;
    this.recipient_client_id = params.recipient_client_id;
    this.dataschema = params.dataschema;
    this.time = params.time;
    this.type = params.type;
    this.datacontenttype = params.datacontenttype;
    this.event_id = params.event_id;
    this.specversion = params.specversion;

    // Split the type into parts
    const typeParts = this.type.split('.');
    if (typeParts.length === 4) {
      this.Provider = `${typeParts[0]}.${typeParts[1]}`;
      this.ContentType = typeParts[2];
      this.EventName = typeParts[3];
    }
  }

  /**
   * Returns the AEM Event as an activity message
   *
   * @returns {string} - AEM Event as activity message
   */
  getEventAsActivityMessage() {
    let eventAsActivityMessage = 'Unable to transform AEM Event as activity message';
    if (this.data && this.data.user && this.data.user.displayName) {
      eventAsActivityMessage = `User ${this.data.user.displayName} ${this.EventName} ${this.ContentType} at ${this.data.path}`;
    }
    return eventAsActivityMessage;
  }

  getEventProvider() {
    return this.Provider;
  }

  getContentType() {
    return this.ContentType;
  }

  getEventName() {
    return this.EventName;
  }

  getAEMHost() {
    let aemHost;
    // Parse the source value
    const sourceParts = this.source.split(':');
    if (sourceParts.length === 2) {
      aemHost = sourceParts[1].split('@')[0];
    }
    return aemHost;
  }

  getEventID() {
    return this.event_id;
  }

  getEventPayload() {
    let eventPayload;
    if (this.data && this.data.payload) {
      eventPayload = this.data.payload;
    }
    return eventPayload;
  }

  getContentPath() {
    let contentPath;
    if (this.data && this.data.path) {
      contentPath = this.data.path;
    }
    return contentPath;
  }

  getUserDisplayName() {
    let userDisplayName;
    if (this.data && this.data.user && this.data.user.displayName) {
      userDisplayName = this.data.user.displayName;
    }
    return userDisplayName;
  }

  getUserPrincipalId() {
    let userPrincipalId;
    if (this.data && this.data.user && this.data.user.principalId) {
      userPrincipalId = this.data.user.principalId;
    }
    return userPrincipalId;
  }

  getProperties() {
    let properties;
    if (this.data && this.data.properties) {
      properties = this.data.properties;
    }
    return properties;
  }

  getTime() {
    return this.time;
  }
}

module.exports = AEMEvent;
