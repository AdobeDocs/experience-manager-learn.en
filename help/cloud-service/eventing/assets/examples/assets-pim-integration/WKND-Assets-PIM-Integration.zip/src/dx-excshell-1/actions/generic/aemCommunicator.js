/* eslint-disable max-len */
/* eslint-disable camelcase */
const { Core } = require('@adobe/aio-sdk');
const fetch = require('node-fetch');
const { AEMConnectionError } = require('../model/errors');

/**
 *  Get IMS Access Token using Client Credentials Flow
 *
 * @param {*} clientId - IMS Client ID from ADC project's OAuth Server-to-Server Integration
 * @param {*} clientSecret - IMS Client Secret from ADC project's OAuth Server-to-Server Integration
 * @param {*} scopes - IMS Meta Scopes from ADC project's OAuth Server-to-Server Integration as comma separated strings
 * @returns {string} - Returns the IMS Access Token
 */
async function getIMSAccessToken(clientId, clientSecret, scopes) {
  const adobeIMSV3TokenEndpointURL = 'https://ims-na1.adobelogin.com/ims/token/v3';

  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `grant_type=client_credentials&client_id=${clientId}&client_secret=${clientSecret}&scope=${scopes}`,
  };

  const response = await fetch(adobeIMSV3TokenEndpointURL, options);
  const responseJSON = await response.json();

  return responseJSON.access_token;
}

/**
 *
 * This function updates the metadata of an AEM Asset using the Assets Author API.
 * The new Assets Author API details are available at https://developer.adobe.com/experience-cloud/experience-manager-apis/api/experimental/assets/author/
 * It uses the Adobe I/O SDK to get the access token from IMS.
 *
 * @param {*} metadataDetails - The metadata details to be updated in AEM
 * @param {*} aemAssetEvent - The original AEM Asset Event object
 * @param {*} params - The action parameters
 * @returns {boolean} - Returns true if the metadata is updated successfully
 */
async function updateAEMAssetMetadata(metadataDetails, aemAssetEvent, params) {
  // create a Logger
  const logger = Core.Logger('updateAEMAssetMetadata', {
    level: 'info',
  });

  // event value is "aem-p63947-e1249010", so replace "aem" with "author" and add ".adobeaemcloud.com"
  const aemAuthorHost = `https://${aemAssetEvent
    .getAEMHost()
    .replace('aem', 'author')}.adobeaemcloud.com`;

  const assetId = aemAssetEvent.getAssetId();

  // Transform the metadata details to JSON Patch format,
  // see https://developer.adobe.com/experience-cloud/experience-manager-apis/api/experimental/assets/author/#operation/patchAssetMetadata
  const transformedMetadata = Object.keys(metadataDetails).map((key) => ({
    op: 'add',
    path: `wknd-${key.toLowerCase()}`,
    value: metadataDetails[key],
  }));

  logger.info(
    `Updating Asset with ID: ${assetId}, @ AEM Host: ${aemAuthorHost}, with metadata: ${JSON.stringify(
      transformedMetadata,
    )}`,
  );

  // Get ADC project's OAuth Server-to-Server Integration credentials
  const clientId = params.ADC_CECREDENTIALS_CLIENTID;
  const clientSecret = params.ADC_CECREDENTIALS_CLIENTSECRET;
  const scopes = params.ADC_CECREDENTIALS_METASCOPES;

  // Get IMS Access Token using Client Credentials Flow
  const access_token = await getIMSAccessToken(clientId, clientSecret, scopes);

  /** Uncomment below lines when debugging
   *
  logger.info(
    `clientId: ${clientId}, clientSecret: ${clientSecret}, scopes: ${scopes}`,
  );
  logger.info(`Access token retrieved from IMS successfully:\n${access_token}`);
   */

  // Call AEM Author service to update the metadata using Assets Author API
  // See https://developer.adobe.com/experience-cloud/experience-manager-apis/api/experimental/assets/author/
  const res = await fetch(`${aemAuthorHost}/adobe/assets/${assetId}/metadata`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json-patch+json',
      'If-Match': '*',
      'X-Adobe-Accept-Experimental': '1',
      'X-Api-Key': 'aem-assets-management-api', // temporary value
      Authorization: `Bearer ${access_token}`,
    },
    body: JSON.stringify(transformedMetadata),
  });

  // If the response is OK,
  if (res.ok) {
    logger.info('AEM Asset Metadata updated successfully');
    const responseJSON = await res.json();
    logger.info(
      `AEM Asset Metadata updated response: ${JSON.stringify(responseJSON)}`,
    );
  } else {
    // If the response is not OK, throw an error
    logger.error(
      `Error updating AEM Asset Metadata, assetId: ${assetId}, aemHost: ${aemAuthorHost}, status code: ${
        res.status
      }, status text: ${res.statusText}, body: ${await res.text()}`,
    );
    throw new AEMConnectionError(`Could not connect to ${aemAuthorHost}`);
  }

  return true;
}

module.exports = { updateAEMAssetMetadata };
