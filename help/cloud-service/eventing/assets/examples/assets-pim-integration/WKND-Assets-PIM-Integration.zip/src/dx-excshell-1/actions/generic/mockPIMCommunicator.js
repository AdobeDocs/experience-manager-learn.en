/**
 * Mock PIM API to get the product data such as SKU, Supplier, etc.
 *
 * In a real-world scenario, this function would call the PIM API to get the product data.
 * For this example, we are returning mock data.
 *
 * @param {string} assetId - The assetId to get the product data.
 */
module.exports = {
  async getPIMData(assetId) {
    if (!assetId) {
      throw new Error('Invalid assetId');
    }
    // Mock response data for demo purposes
    const data = {
      SKUID: 'MockSKU 123',
      SupplierName: 'mock-supplier',
      // ... other product data
    };
    return data;
  },
};
