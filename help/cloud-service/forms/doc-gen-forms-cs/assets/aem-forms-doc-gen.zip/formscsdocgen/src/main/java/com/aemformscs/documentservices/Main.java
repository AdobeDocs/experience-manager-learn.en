package com.aemformscs.documentservices;

import java.io.FileNotFoundException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, NoSuchAlgorithmException, InvalidKeySpecException {
		String postURL = "https://author-p24107-e104692.adobeaemcloud.com/adobe/forms/doc/v1/generatePDFOutput";
	 new DocumentGeneration().mergeDataWithXdpTemplate(postURL);
		
		
		
	}

}
