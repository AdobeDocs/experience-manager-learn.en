/**
* Get List of County names
* @name getCountyNamesList Get list of county names
* @return {OPTIONS} drop down options 
 */
function getCountyNamesList()
{
    var countyNames= [];
	countyNames[0] = "Santa Clara";
	countyNames[1] = "Alameda";
	countyNames[2] = "Buxor";
    countyNames[3] = "Contra Costa";
    countyNames[4] = "Merced";

	return countyNames;

}

/**
* Create GUID 
* @name createGUID Generate GUID to be used as BlobID
* @param {string} strUTCString in String 
* @return {string}
*/
function createGUID(strUTCString)
{

    var dt = new Date().getTime();
   return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,
   function( c ) {
      var rnd = Math.random() * 16;//random number in range 0 to 16
      rnd = (dt + rnd)%16 | 0;
      dt = Math.floor(dt/16);
      return (c === 'x' ? rnd : (rnd & 0x3 | 0x8)).toString(16);
   });
}


/**
* Create a guid
* @name generateGUID BlobId for storing the form data
* @return {string}
*/
function generateGUID() {
   var dt = new Date().getTime();
   return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,
   function( c ) {
      var rnd = Math.random() * 16;//random number in range 0 to 16
      rnd = (dt + rnd)%16 | 0;
      dt = Math.floor(dt/16);
      return (c === 'x' ? rnd : (rnd & 0x3 | 0x8)).toString(16);
   });
}





