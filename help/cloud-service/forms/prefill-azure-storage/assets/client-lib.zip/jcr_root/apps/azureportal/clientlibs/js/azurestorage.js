$(document).ready(function() {

    var suc = function(obj) {
        var afData = obj.data;
        console.log("The form data is "+afData);
        let xhr = new XMLHttpRequest();
        xhr.open('POST','/bin/saveinazureportal');
        let formData = new FormData();
    	formData.append("formData", afData);
        xhr.send(formData);


    };

     var err = function(obj) {

        console.log("The error");
    };

    $(".saveform").click(function(){
        console.log("save form clicked");
        guideBridge.getData({success:suc,error:err});
    });
    console.log(" azure storage!!!!!");






});
