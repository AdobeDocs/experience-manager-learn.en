package com.aem.bankingapplication.core;

import com.adobe.granite.auth.saml.spi.Assertion;
import com.adobe.granite.auth.saml.spi.Attribute;
import com.adobe.granite.auth.saml.spi.Message;
import com.adobe.granite.auth.saml.spi.SamlHook;
import org.apache.sling.auth.core.spi.AuthenticationInfo;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

@Component
@Designate(ocd = EntraSamlHook.Configuration.class, factory = true)
public class EntraSamlHook implements SamlHook {

    private static final Logger LOG =
            LoggerFactory.getLogger(EntraSamlHook.class);

    private HttpClient httpClient;
    private String aepUrl;
    private String aepFlowId;

    @ObjectClassDefinition(
            name = "Entra SAML Login Hook Configuration"
    )
    public @interface Configuration {

        @AttributeDefinition(
                name = "idpIdentifier",
                description = "Must exactly match the Entra SAML Authentication Handler idpIdentifier"
        )
        String idpIdentifier();

        @AttributeDefinition(
                name = "AEP Streaming URL",
                description = "AEP HTTP streaming ingestion endpoint"
        )
        String aepUrl();

        @AttributeDefinition(
                name = "AEP Flow ID",
                description = "AEP dataflow ID"
        )
        String aepFlowId();
    }

    @Activate
    protected void activate(Configuration config) {
        this.aepUrl = config.aepUrl();
        this.aepFlowId = config.aepFlowId();

        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();

        LOG.info("EntraSamlHook activated");
        LOG.info("AEP URL configured: {}", aepUrl);
        LOG.info("AEP Flow ID configured: {}", aepFlowId);
    }

    @Override
    public void postSamlValidationProcess(
            HttpServletRequest request,
            Assertion assertion,
            Message samlResponse) {
        // Nothing required here.
    }

    @Override
    public void postSyncUserProcess(
            HttpServletRequest request,
            HttpServletResponse response,
            Assertion assertion,
            AuthenticationInfo authenticationInfo,
            String samlResponse) {

        String aemUserId = authenticationInfo.getUser();

        Map<String, Attribute> attributes = assertion.getAttributes();
        LOG.warn("SAML attributes received from Entra: {}", attributes.keySet());
           LOG.info("SAML attributes received from Entr: {}", attributes.keySet());

        String entraObjectId =
                getAttributeValue(attributes.get("objectId"));

        String email =
                getAttributeValue(
                        attributes.get(
                                "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"
                        )
                );
String firstName = getAttributeValue(
    attributes.get(
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"
    )
);

String lastName = getAttributeValue(
    attributes.get(
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"
    )
);
  
        LOG.info("==================================================");
        LOG.info("ENTRA SAML POST-SYNC HOOK FIRED");
        LOG.info("AEM User ID: {}", aemUserId);
        LOG.info("Entra Object ID: {}", entraObjectId);
        LOG.info("Email: {}", email);
        LOG.info("First Name: {}", firstName);
        LOG.info("Last Name: {}", lastName);

        if (isBlank(entraObjectId)
                || isBlank(email)
                || isBlank(firstName)
                || isBlank(lastName)) {

            LOG.warn(
                    "Required Entra profile attributes are missing. AEP sync skipped."
            );
            return;
        }

        String payload = buildAepPayload(
                entraObjectId,
                email,
                firstName,
                lastName
        );

        LOG.info("Sending Entra profile to AEP");
        LOG.info("AEP request payload: {}", payload);

        try {
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(aepUrl))
                    .timeout(Duration.ofSeconds(10))
                    .header("Content-Type", "application/json")
                    .header("x-adobe-flow-id", aepFlowId)
                    .POST(HttpRequest.BodyPublishers.ofString(payload))
                    .build();

            HttpResponse<String> aepResponse =
                    httpClient.send(
                            httpRequest,
                            HttpResponse.BodyHandlers.ofString()
                    );

            int statusCode = aepResponse.statusCode();

            if (statusCode >= 200 && statusCode < 300) {
                LOG.info(
                        "AEP profile ingestion succeeded. HTTP {}",
                        statusCode
                );

                LOG.info(
                        "AEP response: {}",
                        aepResponse.body()
                );
            } else {
                LOG.error(
                        "AEP profile ingestion failed. HTTP {} Response: {}",
                        statusCode,
                        aepResponse.body()
                );
            }

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();

            LOG.error(
                    "AEP profile ingestion was interrupted",
                    e
            );

        } catch (IOException | RuntimeException e) {

            LOG.error(
                    "AEP profile ingestion failed",
                    e
            );
        }

        LOG.info("==================================================");
    }

    private String getAttributeValue(Attribute attribute) {

        if (attribute == null || attribute.getValue() == null) {
            return null;
        }

        return String.valueOf(attribute.getValue());
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private String buildAepPayload(
            String entraObjectId,
            String email,
            String firstName,
            String lastName) {

        return "{"
                + "\"_techmarketingdemos\":{"
                + "\"crmid\":\"" + escapeJson(entraObjectId) + "\","
                + "\"Email\":\"" + escapeJson(email) + "\","
                + "\"FirstName\":\"" + escapeJson(firstName) + "\","
                + "\"LastName\":\"" + escapeJson(lastName) + "\""
                + "}"
                + "}";
    }

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }
}