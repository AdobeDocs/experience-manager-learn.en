package com.aem.bankingapplication.core;

import com.adobe.granite.auth.saml.spi.Assertion;
import com.adobe.granite.auth.saml.spi.Attribute;
import com.adobe.granite.auth.saml.spi.Message;
import com.adobe.granite.auth.saml.spi.SamlHook;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.auth.core.spi.AuthenticationInfo;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFactory;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

@Component
@Designate(ocd = EntraSamlHook.Configuration.class, factory = true)
public class EntraSamlHook implements SamlHook {

    private static final Logger LOG =
            LoggerFactory.getLogger(EntraSamlHook.class);

    private static final String SERVICE_USER_NAME = "saml-hook-service";

    private static final String AEP_SYNCED_PROPERTY =
            "profile/aepSynced";

    private static final String OBJECT_ID_ATTRIBUTE =
            "objectId";

    private static final String EMAIL_ATTRIBUTE =
            "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";

    private static final String GIVEN_NAME_ATTRIBUTE =
            "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname";

    private static final String SURNAME_ATTRIBUTE =
            "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname";

    private HttpClient httpClient;

    private String aepUrl;

    private String aepFlowId;

    private String idpIdentifier;

    @Reference
    private SlingRepository repository;

    @ObjectClassDefinition(
            name = "Entra SAML Login Hook Configuration"
    )
    public @interface Configuration {

        @AttributeDefinition(
                name = "idpIdentifier",
                description =
                        "Must exactly match the Entra SAML Authentication Handler idpIdentifier"
        )
        String idpIdentifier();

        @AttributeDefinition(
                name = "AEP Streaming URL",
                description = "AEP HTTP streaming ingestion endpoint"
        )
        String aepUrl();

        @AttributeDefinition(
                name = "AEP Flow ID",
                description = "AEP dataflow ID"
        )
        String aepFlowId();
    }

    @Activate
    protected void activate(Configuration config) {

        this.idpIdentifier = config.idpIdentifier();
        this.aepUrl = config.aepUrl();
        this.aepFlowId = config.aepFlowId();

        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();

        LOG.info("EntraSamlHook activated");
        LOG.info("Configured IdP identifier: {}", idpIdentifier);
        LOG.info("AEP URL configured: {}", aepUrl);
        LOG.info("AEP Flow ID configured: {}", aepFlowId);
    }

    @Override
    public void postSamlValidationProcess(
            HttpServletRequest request,
            Assertion assertion,
            Message samlResponse) {

        // Nothing required here.
    }

    @Override
    public void postSyncUserProcess(
            HttpServletRequest request,
            HttpServletResponse response,
            Assertion assertion,
            AuthenticationInfo authenticationInfo,
            String samlResponse) {

        LOG.info("==================================================");
        LOG.info("ENTRA SAML POST-SYNC HOOK FIRED");

        Session serviceSession = null;

        try {

            if (authenticationInfo == null) {
                LOG.warn("AuthenticationInfo is null. AEP sync skipped.");
                return;
            }

            String userId = authenticationInfo.getUser();

            LOG.info("AuthenticationInfo user: {}", userId);

            if (isBlank(userId)) {
                LOG.warn(
                        "AuthenticationInfo user is blank. AEP sync skipped."
                );
                return;
            }

            Map<String, Attribute> attributes =
                    assertion != null
                            ? assertion.getAttributes()
                            : null;

            if (attributes == null) {
                LOG.warn(
                        "No SAML attributes were received. AEP sync skipped."
                );
                return;
            }

            String entraObjectId =
                    getAttributeValue(
                            attributes.get(OBJECT_ID_ATTRIBUTE)
                    );

            String email =
                    getAttributeValue(
                            attributes.get(EMAIL_ATTRIBUTE)
                    );

            String firstName =
                    getAttributeValue(
                            attributes.get(GIVEN_NAME_ATTRIBUTE)
                    );

            String lastName =
                    getAttributeValue(
                            attributes.get(SURNAME_ATTRIBUTE)
                    );

            LOG.info("Entra Object ID: {}", entraObjectId);
            LOG.info("Email: {}", email);
            LOG.info("First Name: {}", firstName);
            LOG.info("Last Name: {}", lastName);

            if (isBlank(entraObjectId)
                    || isBlank(email)
                    || isBlank(firstName)
                    || isBlank(lastName)) {

                LOG.warn(
                        "Required Entra profile attributes are missing. " +
                        "AEP sync skipped."
                );

                return;
            }

            /*
             * Open ONE service session and keep it alive for the
             * entire operation.
             */
            serviceSession =
                    repository.loginService(
                            SERVICE_USER_NAME,
                            null
                    );

            LOG.info(
                    "Service session user: {}",
                    serviceSession.getUserID()
            );

            LOG.info(
                    "Can see /home/users: {}",
                    serviceSession.nodeExists("/home/users")
            );

            UserManager userManager =
                    ((JackrabbitSession) serviceSession)
                            .getUserManager();

            /*
             * Since AEM userIDAttribute is configured as "objectId",
             * authenticationInfo.getUser() is now the stable AEM
             * authorizable ID.
             *
             * No findAuthorizables() query is required.
             */
            Authorizable user =
                    userManager.getAuthorizable(userId);

            if (user == null) {

                LOG.warn(
                        "AEM user not found: {}",
                        userId
                );

                return;
            }

            if (user.isGroup()) {

                LOG.warn(
                        "Resolved authorizable is a group, not a user: {}",
                        userId
                );

                return;
            }

            LOG.info(
                    "Found AEM user: {}",
                    user.getID()
            );

            LOG.info(
                    "AEM user path: {}",
                    user.getPath()
            );

            /*
             * Check the AEP flag while the service session is still open.
             */
            if (isAepAlreadySynced(user)) {

                LOG.info(
                        "AEP profile already synchronized for AEM user {}. " +
                        "Skipping AEP ingestion.",
                        user.getID()
                );

                return;
            }

            String payload =
                    buildAepPayload(
                            entraObjectId,
                            email,
                            firstName,
                            lastName
                    );

            LOG.info(
                    "Sending Entra profile to AEP for user {}",
                    user.getID()
            );

            HttpRequest httpRequest =
                    HttpRequest.newBuilder()
                            .uri(URI.create(aepUrl))
                            .timeout(Duration.ofSeconds(10))
                            .header(
                                    "Content-Type",
                                    "application/json"
                            )
                            .header(
                                    "x-adobe-flow-id",
                                    aepFlowId
                            )
                            .POST(
                                    HttpRequest.BodyPublishers
                                            .ofString(payload)
                            )
                            .build();

            HttpResponse<String> aepResponse =
                    httpClient.send(
                            httpRequest,
                            HttpResponse.BodyHandlers.ofString()
                    );

            int statusCode = aepResponse.statusCode();

            if (statusCode >= 200 && statusCode < 300) {

                LOG.info(
                        "AEP profile ingestion succeeded. HTTP {}",
                        statusCode
                );

                LOG.info(
                        "AEP response: {}",
                        aepResponse.body()
                );

                /*
                 * Set the flag ONLY after AEP succeeds.
                 *
                 * The same service session is still alive here.
                 */
                markAepAsSynced(
                        user,
                        serviceSession
                );

            } else {

                LOG.error(
                        "AEP profile ingestion failed. HTTP {} Response: {}",
                        statusCode,
                        aepResponse.body()
                );
            }

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();

            LOG.error(
                    "AEP profile ingestion was interrupted",
                    e
            );

        } catch (
                IOException
                | RepositoryException
                | RuntimeException e) {

            LOG.error(
                    "Error during Entra/AEP synchronization",
                    e
            );

        } finally {

            if (serviceSession != null) {
                serviceSession.logout();
            }

            LOG.info("==================================================");
        }
    }

    /**
     * Checks whether the AEP sync flag is already true.
     *
     * The Authorizable MUST be used while the repository session
     * from which it was obtained is still open.
     */
    private boolean isAepAlreadySynced(
            Authorizable user)
            throws RepositoryException {

        if (!user.hasProperty(AEP_SYNCED_PROPERTY)) {
            return false;
        }

        Value[] values =
                user.getProperty(AEP_SYNCED_PROPERTY);

        return values != null
                && values.length > 0
                && values[0].getBoolean();
    }

    /**
     * Marks the user as successfully sent to AEP.
     *
     * The caller passes the SAME open session that owns the Authorizable.
     */
    private void markAepAsSynced(
            Authorizable user,
            Session serviceSession)
            throws RepositoryException {

        ValueFactory valueFactory =
                serviceSession.getValueFactory();

        user.setProperty(
                AEP_SYNCED_PROPERTY,
                valueFactory.createValue(true)
        );

        serviceSession.save();

        LOG.info(
                "Set {}=true for AEM user {}",
                AEP_SYNCED_PROPERTY,
                user.getID()
        );
    }

    private String getAttributeValue(
            Attribute attribute) {

        if (attribute == null
                || attribute.getValue() == null) {

            return null;
        }

        return String.valueOf(
                attribute.getValue()
        );
    }

    private boolean isBlank(String value) {

        return value == null
                || value.isBlank();
    }

    private String buildAepPayload(
            String entraObjectId,
            String email,
            String firstName,
            String lastName) {

        return "{"
                + "\"_techmarketingdemos\":{"
                + "\"crmid\":\""
                + escapeJson(entraObjectId)
                + "\","
                + "\"Email\":\""
                + escapeJson(email)
                + "\","
                + "\"FirstName\":\""
                + escapeJson(firstName)
                + "\","
                + "\"LastName\":\""
                + escapeJson(lastName)
                + "\""
                + "}"
                + "}";
    }

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }
}