package com.aemformscs.documentservices;

import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.JSONObject;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

public class GetOptions {
	
	static public String getPDFAOptions()
	{
		 ClassLoader classLoader = GetOptions.class.getClassLoader();
	     InputStream pdfOptionsFile = classLoader.getResourceAsStream("credentials/pdfa-options.json");
	     JsonReader jsonReader = new JsonReader(new InputStreamReader(pdfOptionsFile));

	     JsonElement jsonElement = JsonParser.parseReader(jsonReader);
	     System.out.println("The jsonElement is " + jsonElement.isJsonObject());
	     return jsonElement.getAsJsonObject().toString();

	}
static public String getPDFOptions()
{
	 ClassLoader classLoader = GetOptions.class.getClassLoader();
     InputStream credentialsFiles = classLoader.getResourceAsStream("credentials/options.json");
     JsonReader jsonReader = new JsonReader(new InputStreamReader(credentialsFiles));

     JsonElement jsonElement = JsonParser.parseReader(jsonReader);
     System.out.println("The jsonElement is " + jsonElement.isJsonObject());
     return jsonElement.getAsJsonObject().toString();

}
static public String getEmbeddFontsOptions()
{
	 ClassLoader classLoader = GetOptions.class.getClassLoader();
     InputStream credentialsFiles = classLoader.getResourceAsStream("credentials/customfonts.json");
     JsonReader jsonReader = new JsonReader(new InputStreamReader(credentialsFiles));

     JsonElement jsonElement = JsonParser.parseReader(jsonReader);
     System.out.println("The jsonElement is " + jsonElement.isJsonObject());
     System.out.println(jsonElement.getAsJsonObject().toString());
     return jsonElement.getAsJsonObject().toString();

}
static public String getDummyJson()
{
	JsonObject jsonObject = new JsonObject();
	return jsonObject.toString();
	
}
static public String getBatchOptions()
{
	ClassLoader classLoader = GetOptions.class.getClassLoader();
    InputStream credentialsFiles = classLoader.getResourceAsStream("credentials/batch_options.json");
    JsonReader jsonReader = new JsonReader(new InputStreamReader(credentialsFiles));

    JsonElement jsonElement = JsonParser.parseReader(jsonReader);
    System.out.println("The jsonElement is " + jsonElement.isJsonObject());
    System.out.println(jsonElement.getAsJsonObject().toString());
    return jsonElement.getAsJsonObject().toString();
}
}
