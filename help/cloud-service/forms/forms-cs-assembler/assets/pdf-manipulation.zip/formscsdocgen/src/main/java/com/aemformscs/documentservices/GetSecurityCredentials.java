package com.aemformscs.documentservices;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.JSONException;
import org.json.JSONObject;

public class GetSecurityCredentials {
	//Returns a json object from an input stream
	public JSONObject getJsonObject(){

	    //Create input stream
		 ClassLoader classLoader = getClass().getClassLoader();
         InputStream credentialsFiles = classLoader.getResourceAsStream("credentials/options.json");


	   try {
	       BufferedReader streamReader = new BufferedReader(new InputStreamReader(credentialsFiles, "UTF-8"));
	       StringBuilder responseStrBuilder = new StringBuilder();

	       String inputStr;
	       while ((inputStr = streamReader.readLine()) != null)
	           responseStrBuilder.append(inputStr);

	       JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
	       System.out.println(jsonObject.toString());

	       //returns the json object
	       return jsonObject;

	   } catch (IOException e) {
	       e.printStackTrace();
	   } catch (JSONException e) {
	       e.printStackTrace();
	   }

	    //if something went wrong, return null
	    return null;
	}

}
