function getBucketName(hostname) {
  if (hostname) {
    return hostname.split(".adobeaemcloud.com")[0].split("https://")[1];
  } else {
    return "";
  }
}

export { getBucketName };
