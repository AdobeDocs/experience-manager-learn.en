const APP_CONFIG = {
  // Adobe related configurations such as IMS, ADC, and AEM
  adobe: {
    ims: {
      authorizationEndpoint:
        process.env.REACT_APP_ADOBE_IMS_AUTHORIZATION_ENDPOINT,
      tokenEndpoint: process.env.REACT_APP_ADOBE_IMS_TOKEN_ENDPOINT,
      userInfoEndpoint: process.env.REACT_APP_ADOBE_IMS_USERINFO_ENDPOINT,
    },

    adc: {
      clientId: process.env.REACT_APP_ADC_CLIENT_ID,
      scopes: process.env.REACT_APP_ADC_SCOPES,
    },

    aem: {
      hostname: process.env.REACT_APP_AEM_ASSET_HOSTNAME,
    },

    spa: {
      redirectUri: process.env.REACT_APP_REDIRECT_URI,
    },
  },
};

export default APP_CONFIG;
