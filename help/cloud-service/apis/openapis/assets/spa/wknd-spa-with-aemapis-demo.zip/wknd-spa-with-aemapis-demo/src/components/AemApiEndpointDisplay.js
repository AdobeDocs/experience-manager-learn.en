import React from "react";
import APP_CONFIG from "../config/config";

function AemApiEndpointDisplay() {
  return (
    <p className="api-endpoint">
      AEM APIs will be invoked against{" "}
      <a 
        href={APP_CONFIG.adobe.aem.hostname}
        target="_blank"
        rel="noopener noreferrer"
      >
        {APP_CONFIG.adobe.aem.hostname}
      </a>
    </p>
  );
}

export default AemApiEndpointDisplay; 