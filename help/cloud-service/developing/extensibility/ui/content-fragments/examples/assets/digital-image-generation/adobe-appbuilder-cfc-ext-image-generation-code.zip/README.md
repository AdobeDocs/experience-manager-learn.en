# Adobe AppBuilder Project :: Image Generation Code

- This zip artifact only contains the KEY FILES from `web-src` and `actions` folders, such as Modal React component (GenerateImageModal.js) and Adobe I/O runtime action index and module files (index.js,generate-image-using-openai.js, etc). 

- The other Adobe AppBuilder - template generated files are not provided so that you can keep using the latest updates coming from upstream template enhancements

- Regarding the Node modules or libraries, below is the `dependencies` snippet from package.json file for your reference

	```json
		{
		  ...

		  "dependencies": {
			...		 
		    
		    "@adobe/aem-upload": "^1.4.1",
		    "openai": "^3.1.0",
		    
		  }

		  ...
		}

	```

- Please follow the tutorial and incorporate these custom files to get the demo working
