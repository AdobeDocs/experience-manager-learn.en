module.exports = {
  extensionId: 'cf-console-imgagegeneration-actionbar',
};
