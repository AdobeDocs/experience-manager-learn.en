module.exports = {
  extensionId: 'cfe-custom-field'
}
