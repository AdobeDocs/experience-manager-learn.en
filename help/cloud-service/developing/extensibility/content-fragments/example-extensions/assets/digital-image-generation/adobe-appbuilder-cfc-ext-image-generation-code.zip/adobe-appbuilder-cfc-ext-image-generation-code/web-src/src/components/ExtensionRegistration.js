/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable max-len */
/* eslint-disable import/no-extraneous-dependencies */
/*
 * <license header>
 */

import { Text } from '@adobe/react-spectrum';
import { register } from '@adobe/uix-guest';
import { generatePath } from 'react-router';

import { extensionId } from './Constants';

function ExtensionRegistration() {
  const init = async () => {
    const guestConnection = await register({
      id: extensionId,
      methods: {

        // Configure your Action Bar button here
        actionBar: {
          getButton() {
            return {
              id: 'generate-image',
              label: 'Generate Image',
              icon: 'PublishCheck',
            };
          },

          onClick(selections) {
            // Collect the selected content fragment paths
            const selectionIds = selections.map((selection) => selection.id);

            const modalURL = `/index.html#${generatePath(
              '/content-fragment/:selection/generate-image-modal',
              {
                // Set the :selection React route parameter to an encoded, delimited list of paths of the selected content fragments
                selection: encodeURIComponent(selectionIds.join('|')),
              },
            )}`;

            console.log('Modal URL: ', modalURL);

            guestConnection.host.modal.showUrl({
              title: 'Generate Image',
              url: modalURL,
            });
          },
        },

      },
    });
  };
  init().catch(console.error);

  return <Text>IFrame for integration with Host (AEM)...</Text>;
}

export default ExtensionRegistration;
