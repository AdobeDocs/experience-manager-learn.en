/* eslint-disable react/jsx-filename-extension */
/*
 * <license header>
 */

import React from 'react';
import ErrorBoundary from 'react-error-boundary';

import { HashRouter as Router, Routes, Route } from 'react-router-dom';

import ExtensionRegistration from './ExtensionRegistration';

import GenerateImageModal from './GenerateImageModal';

// Methods

// error handler on UI rendering failure
function onError(e, componentStack) { }

// component to show if UI fails rendering
function fallbackComponent({ componentStack, error }) {
  return (
    <>
      <h1 style={{ textAlign: 'center', marginTop: '20px' }}>
        Phly, phly... Something went wrong :(
      </h1>
      <pre>{`${componentStack}\n${error.message}`}</pre>
    </>
  );
}

function App(props) {
  return (
    <Router>
      <ErrorBoundary onError={onError} FallbackComponent={fallbackComponent}>
        <Routes>
          <Route index element={<ExtensionRegistration />} />

          <Route
            exact
            path="content-fragment/:selection/generate-image-modal"
            element={<GenerateImageModal />}
          />

        </Routes>
      </ErrorBoundary>
    </Router>
  );
}

export default App;
