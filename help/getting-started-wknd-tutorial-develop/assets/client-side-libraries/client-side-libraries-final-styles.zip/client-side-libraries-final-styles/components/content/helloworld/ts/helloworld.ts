export class HelloWorld {
    constructor() {
        const tsString = "Hello World";
    }
}

export const helloWorld = new HelloWorld();
