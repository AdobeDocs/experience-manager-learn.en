let jsHelloWorld = () => {
    const jsString = "Hello World";
}
export default jsHelloWorld();
