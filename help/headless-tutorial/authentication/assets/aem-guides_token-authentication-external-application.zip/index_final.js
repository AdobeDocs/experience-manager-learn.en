/*
Copyright 2020 Adobe. All rights reserved.

This file is licensed to you under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License. You may obtain a copy
of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under
the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
OF ANY KIND, either express or implied. See the License for the specific language
governing permissions and limitations under the License.
*/

const fetch = require('node-fetch');
const fs = require('fs');
const auth = require('@adobe/jwt-auth');

// The root context of the Assets HTTP API
const ASSETS_HTTP_API = '/api/assets';

// Command line parameters
let params = { };

/**
 * Application entry point function
 */
(async () => {
    console.log('Example usage: node index.js aem=https://author-p1234-e5678.adobeaemcloud.com propertyName=metadata/dc:rights propertyValue="WKND Limited Use" folder=/wknd/en/adventures/napa-wine-tasting file=credentials-file.json' );

    // Parse the command line parameters
    params = getCommandLineParams();
    
    // Set the access token to be used in the HTTP requests to be local development access token
    params.accessToken = await getAccessToken(params.developerConsoleCredentials);

    // Get a list of all the assets in the specified folder
    let assets = await listAssetsByFolder(params.folder);

    // For each asset, update it's metadata
    await assets.forEach(asset => updateMetadata(asset, { 
        [params.propertyName]: params.propertyValue 
    }));
})();

/**
 * Returns a list of Assets HTTP API asset URLs that reference the assets in the specified folder.
 * 
 * https://experienceleague.adobe.com/docs/experience-manager-cloud-service/assets/admin/mac-api-assets.html?lang=en#retrieve-a-folder-listing
 * 
 * @param {*} folder the Assets HTTP API folder path (less the /content/dam path prefix)
 */
async function listAssetsByFolder(folder) {
    return fetch(`${params.aem}${ASSETS_HTTP_API}${folder}.json`, {
            method: 'get',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + params.accessToken
            },
        })
        .then(res => {
            console.log(`${res.status} - ${res.statusText} @ ${params.aem}${ASSETS_HTTP_API}${folder}.json`);
            
            // If success, return the JSON listing assets from AEM, otherwise return empty results
            return res.status === 200 ? res.json() : { entities: [] };
        })
        .then(json => { 
            // Returns a list of all URIs for each non-content fragment asset in the folder
            return json.entities
                .filter((entity) => entity['class'].indexOf('asset/asset') === -1 && !entity.properties.contentFragment)
                .map(asset => asset.links.find(link => link.rel.find(r => r === 'self')).href);
        });
}

/**
 * Update the metadata of an asset in AEM
 * 
 * https://experienceleague.adobe.com/docs/experience-manager-cloud-service/assets/admin/mac-api-assets.html?lang=en#update-asset-metadata
 * 
 * @param {*} asset the Assets HTTP API asset URL to update
 * @param {*} metadata the metadata to update the asset with
 */
async function updateMetadata(asset, metadata) {        
     await fetch(`${asset}`, {
            method: 'put',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + params.accessToken
            },
            body: JSON.stringify({
                class: 'asset',
                properties: metadata
            })
        })
        .then(res => { 
            console.log(`${res.status} - ${res.statusText} @ ${asset}`);
        });
}

/**
 * Parse and return the command line parameters. Expected params are:
 * 
 * - aem = The AEM as a Cloud Service hostname to connect to.
 *              Example: https://author-p12345-e67890.adobeaemcloud.com
 * - folder = The asset folder to update assets in. Note that the Assets HTTP API do NOT use the JCR `/content/dam` path prefix.
 *              Example: '/wknd/en/adventures/napa-wine-tasting'
 * - propertyName = The asset property name to update. Note this is relative to the [dam:Asset]/jcr:content node of the asset.
 *              Example: metadata/dc:rights
 * - propertyValue = The value to update the asset property (specified by propertyName) with.
 *              Example: "WKND Free Use"
 * - file = The path to the JSON file that contains the credentials downloaded from AEM Developer Console
 *              Example: local_development_token_cm_p1234-e5678.json 
 */
function getCommandLineParams() {
    let parameters = {};

    // Parse the command line params, splitting on the = delimiter
    for (let i = 2; i < process.argv.length; i++) {
        let key = process.argv[i].split('=')[0];
        let value = process.argv[i].split('=')[1];

        parameters[key] = value;
    };

    // Read in the credentials from the provided JSON file
    if (parameters.file) {
        parameters.developerConsoleCredentials = JSON.parse(fs.readFileSync(parameters.file));
    }

    console.log(parameters);

    return parameters;
}

async function getAccessToken(developerConsoleCredentials) {
    
    if (developerConsoleCredentials.accessToken) {
        // This is a Local Development access token
        return developerConsoleCredentials.accessToken;
    } /* else {
        // This is the Service Credentials JSON object that must be exchanged with Adobe IMS for an access token
        let serviceCredentials = developerConsoleCredentials.integration;

        // Use the @adobe/jwt-auth library to pass the service credentials generated a JWT and exchange that with Adobe IMS for an access token.
        // If other programming languages are used, please see these code samples: https://www.adobe.io/authentication/auth-methods.html#!AdobeDocs/adobeio-auth/master/JWT/samples/samples.md
        let { access_token } = await auth({
            clientId: serviceCredentials.technicalAccount.clientId,
            technicalAccountId: serviceCredentials.id,
            orgId: serviceCredentials.org,
            clientSecret: serviceCredentials.technicalAccount.clientSecret,
            privateKey: serviceCredentials.privateKey,
            metaScopes: serviceCredentials.metascopes.split(','),
            ims: `https://${serviceCredentials.imsEndpoint}`,
        });

        return access_token;
    } */
}