/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { Theme } from "../theme";
import formatPhone from "../utils/formatPhone";

export default function Administrator({ data }) {
    
    if (!data || !data.fullName) {
        return null;
    }
    const {fullName, contactInfo, biography: {html}}  = data;
    return (
      <>
      <h1 style={styles.title}> Adventure Administrator </h1>
      <p style={styles.Description}>{fullName} </p>
      <p style={styles.Description}> {formatPhone(contactInfo.phone)}</p> 
      <p style={styles.Description}> {contactInfo.email}</p>
      <p style={styles.Description}> <b>About: </b></p>
      <div dangerouslySetInnerHTML={{__html: html}} />
      </>
    )
}

const styles = {
  title:{
    marginTop: "6rem",
  },
  description: {
    padding: "1rem",
    backgroundColor: Theme.colors.detailBackground,
    color: Theme.colors.detailText,
    flex: 1
  },
   headerContainer: {
    display: "flex",
    flexDirection: "row",
    padding: "1rem 0",
    alignItems: "center",
  },
    titleSkeleton: {
    height: "2.5rem",
    width: "85%",
    margin: "1rem"
  },
}