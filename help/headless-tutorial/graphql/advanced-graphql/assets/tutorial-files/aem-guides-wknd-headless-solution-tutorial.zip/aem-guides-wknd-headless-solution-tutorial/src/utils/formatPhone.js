/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
const formatPhone = (phone) => {
      const [areaCode, ...remaining] =  phone.split("-");
      return "(" + areaCode + ") " + remaining.join("-");
}
export default formatPhone;