/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { getRemoteImageSrc } from "../utils";

export default function Location({data}) {


    if(!data || !data.address) {
        return null;
    }

    // Default Render view
    const { address, contactInfo, description, locationImage, name, weatherBySeason } = data;
    const getSeason = d => ['winter', 'spring', 'summer', 'fall'][Math.floor((d.getMonth() / 12 * 4)) % 4];

    return (
        <>
        <h1 style={styles.locationTitle}> WHERE To MEET</h1>
      <div style={styles.container}>
        
        <h1 style={styles.title}> {name} </h1>
          <p style={styles.description}>{`${data.address.streetAddress}, ${address.city} ${address.state} ${address.zipCode}, ${address.country}`} </p>
          <p style={styles.description}> {`${contactInfo.phone}`}</p> 
          <p style={styles.description}> {`${contactInfo.email}`}</p> 
        <div style={styles.parentContainer}>
          <div style={styles.imageContainer}>
            <img style={styles.image} src={getRemoteImageSrc(locationImage._path)} alt={name} />
          </div>
          <div style={styles.childContainer}>
            { description.json.map((node, key) => {
               return <p style={styles.asideDescription} key={key}>{node.content.map(({ value }) => value)}</p>
            })}
          </div>
        </div>
        <p> <b> Current Average Temperature: </b> {weatherBySeason[getSeason(new Date())]}</p>
      </div>
      </>
    )
  }

const styles = {
    locationTitle: {
        fontSize: "2rem",
        textTransform: "uppercase",
        marginTop: "6rem",
      },  
  container: {
    flex: 1,
  },
  parentContainer: {
    display: "flex",
    marginTop: "1.5rem",
  },
  childContainer:{
    flex:1,
  },
  title: {
    textTransform: "uppercase",
    marginTop: "1.5rem",
  },
  description: {
    margin: 0,
    lineHeight: "1.6"
  },
  asideDescription:{
    paddingLeft: "20px",
    lineHeight: "1.6"
  },
  imageContainer: {
    flex: 1,
    overflow: "hidden",
  },
  image : {
    maxHeight: "100%",
    maxWidth: "100%",
  },
  headerContainer: {
    display: "flex",
    flexDirection: "row",
    padding: "1rem 0",
    alignItems: "center",
  },
    titleSkeleton: {
    height: "2.5rem",
    width: "85%",
    margin: "1rem"
  },
}