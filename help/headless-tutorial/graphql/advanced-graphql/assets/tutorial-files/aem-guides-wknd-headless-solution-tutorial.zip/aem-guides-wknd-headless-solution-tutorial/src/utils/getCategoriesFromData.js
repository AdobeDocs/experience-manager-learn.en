/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { sanitizeActivity } from "./sanitizeActivity";

export const getCategoriesFromData = (items) => {
  let categories = { };
  items.forEach(item => {
    if (!item.adventureActivity) categories.miscellaneous = item;
    else {
      const activity = sanitizeActivity(item.adventureActivity);
      if (!categories.hasOwnProperty(activity)) {
        categories[activity] = item
      }
    }
  })

  return categories;
}