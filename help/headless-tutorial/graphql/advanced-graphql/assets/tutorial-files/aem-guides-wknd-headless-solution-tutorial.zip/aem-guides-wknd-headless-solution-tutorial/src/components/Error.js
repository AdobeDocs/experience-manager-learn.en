/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { Theme } from "../theme";

export default function ErrorScreen( {error} ) {
    console.log("Error: " + error);
  try {
    return (
      <div className="content">
        <h1>Error</h1>
        <pre style={styles.pre}>{"Error: " + error}</pre>
      </div>
    );
  } catch (e) {
    return <div>Error with the Error</div>
  }
}

const styles = {
  pre: {
    border: "1px solid rgba(255, 255, 255, .1)",
    borderRadius: "4px",
    padding: "1rem",
    width: "120ch",
    whiteSpace: "normal",
  },
  a: {
    color: Theme.colors.text
  }
}