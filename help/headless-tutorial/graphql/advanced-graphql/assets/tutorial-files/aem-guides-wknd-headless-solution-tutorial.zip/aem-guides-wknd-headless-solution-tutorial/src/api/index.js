export { useGraphQL, useGraphQLPersisted} from "./useGraphQL";
export * from "./queries";