/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
const DetailHeader = () => {

}
<div style={styles.headerContainer}>
  <IoChevronBack onClick={() => window.history.back()} size="2rem" />
  {!title && <div className="loading-skeleton" style={styles.titleSkeleton}></div>}
  {title && <h1 style={styles.title}>{title}</h1>}
</div>