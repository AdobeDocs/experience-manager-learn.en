/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { getRemoteImageSrc } from "../utils";
import formatPhone from "../utils/formatPhone";



export default function Instructor({ data }) {
    
    if (!data) {
        return null;
    }

    // Default Render view
    const {teamMembers} = data;
    const skillsFlatter = (skillsArray) => {
      let skillsStr = "";
      skillsArray.forEach(skill => {
        skillsStr += skill + ", "
      });
      return skillsStr.substr(0, skillsStr.length - 2);
    }
    return (
      <>
      <h1 style={styles.title}> Adventure Instructors </h1>
      {teamMembers.map(({biography, contactInfo, fullName, instructorExperienceLevel, profilePicture, skills}, key)=>(
        <div key={key} style={styles.container}>
          <div style={styles.parentContainer}>
            <div style={styles.imageContainer}>
              <img style={styles.image} src={getRemoteImageSrc(profilePicture._path)} alt={fullName} />  
            </div>
            <div style={styles.childContainer}>
              <h3 style={styles.asideDescription}> {fullName} </h3>
              <p style={styles.asideDescription}> {formatPhone(contactInfo.phone)}</p> 
              <p style={styles.asideDescription}> {contactInfo.email}</p> 
              <p style={styles.asideDescription}> <b> Experience Level: </b> {instructorExperienceLevel}</p> 
              <p style={styles.asideDescription}> <b> Skills: </b> {skillsFlatter(skills)}</p> 
            </div>
          </div>
          <p style={styles.description}> <b> Biography: </b> {biography.plaintext}</p> 
        </div>
      ))}
      </>
    )
  }

const styles = {
  container: {
    flex: 1,
  },
  parentContainer: {
    display: "flex",
    flexWrap: "wrap",
    marginTop: "1.5rem"
  },
  childContainer:{
    flex:6,
  },
  title: {
    textTransform: "uppercase",
    marginTop: "6rem",
  },
  description: {
    margin: 0,
    lineHeight: "1.6"
  },
  asideDescription:{
    paddingLeft: "20px",
    lineHeight: "1.2"
  },
  imageContainer: {
    flex: 1,
    overflow: "hidden",
  },
  image : {
    height: "100%",
    width: "100%",
    objectFit:"contain",
  },
    headerContainer: {
    display: "flex",
    flexDirection: "row",
    padding: "1rem 0",
    alignItems: "center",
  },
    titleSkeleton: {
    height: "2.5rem",
    width: "85%",
    margin: "1rem"
  },
}