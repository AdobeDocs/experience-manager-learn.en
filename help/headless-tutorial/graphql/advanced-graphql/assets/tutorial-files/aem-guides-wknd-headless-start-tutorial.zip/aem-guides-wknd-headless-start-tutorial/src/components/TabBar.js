/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { Link, useLocation } from "react-router-dom";
import { TiHome } from "react-icons/ti";

import { Theme } from "../theme";

export default function TabBar() {

  const tabIconSize = "2rem";
  const location = useLocation();
  const isHomeSelected = location.pathname === "/";

  const getTabStyle = (isSelected) => ({ ...styles.tab, color: isSelected ? Theme.colors.accent : Theme.colors.text });

  return (
    <div style={styles.tabsContainer}>
      <nav style={styles.tabs}>
        <Link to="/" style={getTabStyle(isHomeSelected)}>
          <TiHome size={tabIconSize} />
          <span style={styles.tabText}>Home</span>
        </Link>
      </nav>
    </div>
  )
}

const styles = {
  tabsContainer: {
    zIndex: 10,
    backgroundColor: Theme.colors.background,
    height: "6rem",
  },
  tabs: {
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    height: "100%",
    listStyle: "none",
    margin: 0,
    padding: 0,
    overflow: "hidden",
  },
  tab: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    color: Theme.colors.text,
    flex: 1,
    // padding: "20px",
    textDecoration: "none",
    // flexBasis: "25%",
  },
  tabText: {
    fontFamily: "Source Sans Pro",
  }
}