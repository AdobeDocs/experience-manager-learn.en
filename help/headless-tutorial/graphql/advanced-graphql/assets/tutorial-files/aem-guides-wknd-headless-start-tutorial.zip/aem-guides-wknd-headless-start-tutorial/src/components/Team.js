/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { getRemoteImageSrc } from "../utils";
import Address from "./Address";


export default function Team({data}) {
    if (!data || !data.teamMembers) {
        return null;
    }

    //default render
    const {_metadata:{stringMetadata}, teamFoundingDate, description:{json: descriptionJson}} = data;
    const title = stringMetadata.find(({name}) => name ==="title").value;
    const imagePath = descriptionJson
          .find(({content}) => (content[0].nodeType === "reference" && content[0].data?.mimetype === "image/png")).content[0].data.path;
    const date = new Date(teamFoundingDate);
    const dateOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    const teamPath = descriptionJson
          .find(({content}) => (content[0].nodeType === "reference" && content[0].data?.type === "fragment")).content[0].data.href;
    return (
      <>
      <h1 style={styles.title}> Instructor Team </h1>
      <div style={styles.container}>
         <div style={styles.parentContainer}>
          <div style={styles.imageContainer}>
            <img style={styles.image} src={getRemoteImageSrc(imagePath)} alt={title} />
          </div>
          <div style={styles.childContainer}>
            <h3 style={styles.asideDescription}> {title} </h3>
            { descriptionJson.map((node, key) => {
               const isFragment = node.content[0].nodeType === "reference" && node.content[0].data?.type === "fragment";
               if (isFragment) {
                  return <p style={styles.asideDescription} key={key}> <b> {node.content.map(({ value }) => value)} </b></p>  
               }
               return <p style={styles.asideDescription} key={key}>{node.content.map(({ value }) => value)}</p>
            })}
            {teamPath && <Address _path={teamPath}/>}
          </div> 
      </div>
        <p> <b> Established: </b> {new Intl.DateTimeFormat('en-US',dateOptions).format(date)}</p>
      </div>
      </>
    )
  }

const styles = {
  container: {
    flex: 1,
  },
  parentContainer: {
    display: "flex",
    marginTop: "1.5rem"
  },
  childContainer:{
    flex:3,
  },
  title: {
    textTransform: "uppercase",
    marginTop: "6rem",
  },
  asideDescription:{
    paddingLeft: "20px",
    lineHeight: "1.6"
  },
  imageContainer: {
    flex: 1,
    overflow: "hidden",
  },
  image : {
    width: "100%",
    maxWidth: "100%",
  },
    headerContainer: {
    display: "flex",
    flexDirection: "row",
    padding: "1rem 0",
    alignItems: "center",
  },
    titleSkeleton: {
    height: "2.5rem",
    width: "85%",
    margin: "1rem"
  },
}