/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import React from "react"
import { Theme } from "../theme";
import SearchByCategory from "../components/SearchByCategory";


export default function Adventures() {

  return (
    <div className="content" style={styles.container}>
      <div style={styles.searchByCategory}>
        <h2> Browse by Category</h2>
        <SearchByCategory />
      </div>
    </div>
  )
}

const styles = {
  container: {},
  searchBox: {
    height: "10rem",
    minHeight: "10rem",
    position: "relative",
    overflow: "hidden"
  },
  searchResults: {
    padding: "1rem"
  },
  homepageHero: {
    flex: 1,
    position: "relative",
  },
  homepageHeroTitleSearch: {
    position: "absolute",
    top: ".5rem",
    left: 0,
    right: 0,
    marginTop: ".5rem",
    textAlign: "center",
    zIndex: 10,
  },
  homepageHeroTitle: {
    color: Theme.colors.background,
  },
  homepageHeroImage: {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
  },
  homepageHeroSearch: {
    gridArea: "overlay",
    alignSelf: "flex-start",
    justifySelf: "center",
    padding: ".5rem 1rem",
    marginTop: ".25rem",
    borderRadius: "5rem",
    border: "none",
    boxShadow: "0 0 5px rgba(0,0,0,.1)",
  },
  searchByCategory: {
    padding: "1rem",
  }
}