/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import React from "react";
import { HashRouter, Switch, Route } from "react-router-dom";
import { Theme } from "./theme";
import Adventures from "./screens/Adventures";
import AdventureDetail from "./screens/AdventureDetail";
import TabBar from "./components/TabBar";

import './App.css';

export default function App() {

  return (
    <div id="app-container" style={styles.container}>
      <HashRouter>
        <Switch>
          <Route exact path="/">
            <Adventures />
          </Route>
          <Route path="/detail">
            <AdventureDetail />
          </Route>
        </Switch>
        <TabBar />
      </HashRouter>
    </div>
  );
}

const styles = {
  container: {
    position: "relative",
    backgroundColor: Theme.colors.background,
    paddingTop: "10px",
    color: Theme.colors.text,
  },
}