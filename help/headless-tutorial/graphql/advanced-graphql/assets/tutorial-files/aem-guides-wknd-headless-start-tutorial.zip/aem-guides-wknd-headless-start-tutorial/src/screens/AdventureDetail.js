/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { useLocation } from "react-router-dom";
import { IoChevronBack } from "react-icons/io5";
import { useGraphQL,
        useGraphQLPersisted, 
        adventureDetailQuery} from "../api";
import ErrorScreen from "../components/Error";
import Image from "../components/Image";
import { Theme } from "../theme";
import Location from "../components/Location";
import Instructors from "../components/Instructors";
import Administrator from "../components/Administrator";
import Team from "../components/Team";


export default function AdventureDetail() {

  // parse query parameters passed in the route
  const urlParams = new URLSearchParams(useLocation().search);
  // get the path to the individual Adventure that is going to be rendered
  const adventureFragmentPath = urlParams.get("_path");

  /**
   * UNCOMMENT TO USE PERSISTED QUERY
   */
  // Use a persisted query to request Adventure details based on a given content fragment path
  //const {data, errors} = useGraphQLPersisted("wknd/all-adventure-details", adventureFragmentPath);


  /**
   * Use a standard GraphQL POST query to request Adventure details based on a given content fragment path
   * full query can be seen in `src/api/queries.js`
   */
  const { data, errors } = useGraphQL(adventureDetailQuery(adventureFragmentPath));

  // Error State
  if (errors) {
    return <ErrorScreen error={errors} />;
  }
    
// Loading State
 if (!data) {
    return (
      <div className="content detail-screen" style={styles.container}>
        <div style={styles.headerContainer}>
          <IoChevronBack onClick={() => window.history.back()} size="2rem" />
          <div className="loading-skeleton" style={styles.titleSkeleton}></div>
        </div>
      </div>
    )
  } 
  
  // No content fragment found
    if ( !data?.adventureByPath?.item) {
    return <ErrorScreen error="There was an error with the returned data." />;
    }


    // Default Render view
    const adventure = data.adventureByPath.item;
    const title = adventure.adventureTitle || false;
    const descriptionJSON = adventure.adventureDescription?.json || false;
    const itineraryJSON = adventure.adventureItinerary?.json || false;
    let imgSrc = adventure.adventurePrimaryImage?._path || false;
    const adventureDetails = [];

    if (adventure.adventureActivity) adventureDetails.push({ key: "Activity", value: adventure.adventureActivity })
    if (adventure.adventureType) adventureDetails.push({ key: "Adventure Type", value: adventure.adventureType })
    if (adventure.adventureTripLength) adventureDetails.push({ key: "Trip Length", value: adventure.adventureTripLength })
    if (adventure.adventureGroupSize) adventureDetails.push({ key: "Group Size", value: adventure.adventureGroupSize })
    if (adventure.adventureDifficulty) adventureDetails.push({ key: "Difficulty", value: adventure.adventureDifficulty })
    if (adventure.adventurePrice) adventureDetails.push({ key: "Activity", value: adventure.adventurePrice })

    return (
      <div className="content detail-screen" style={styles.container}>
        <div style={styles.headerContainer}>
          <IoChevronBack onClick={() => window.history.back()} size="2rem" />
          {!title && <div className="loading-skeleton" style={styles.titleSkeleton}></div>}
          {title && <h1 style={styles.title}>{title}</h1>}
        </div>
        <Image imgSrc={imgSrc} alt={title} />
        <div style={styles.description}>
          <div style={styles.adventureDetails}>
            {adventureDetails.map(({ key, value }, index) => (
              <div key={index}>
                <span style={styles.adventureDetailsKey}>{key}</span>
                <p style={styles.adventureDetailsValue}>{value}</p>
              </div>
            ))}
          </div>
          {descriptionJSON && descriptionJSON.map((node, key) => {
            const Element = node.nodeType === "header" ? `${node.style}` : "p";
            return <Element key={key}>{node.content.map(({ value }) => value)}</Element>
          })}
          {itineraryJSON && itineraryJSON.map((node, key) => {
            const isBold = node.content[0].format?.variants[0] === 'bold';
            if (isBold) {
              return <p style={styles.adventureItinerary} key={key}> <b> {node.content.map(({ value }) => value)} </b> </p>;
            }
            return <p style={styles.adventureItinerary} key={key}> {node.content.map(({ value }) => value)}</p>;
            })}
            {/*
              <Location data={adventure.location} />
              <Team data={adventure.instructorTeam}/>
              <Administrator data={adventure.administrator} />             
              <Instructors data={adventure.instructorTeam} />
            */}
        </div>
      </div>
    )
  }

const styles = {
  container: {
    flex: 1,
  },
  title: {
    paddingLeft: ".5rem",
    fontSize: "1.5rem",
    textTransform: "uppercase",
    maxWidth: "100%",
    margin: 0,
  },
  locationTitle: {
    fontSize: "2rem",
    textTransform: "uppercase",
    marginTop: "6rem",
  },
  description: {
    padding: "1rem",
    backgroundColor: Theme.colors.detailBackground,
    color: Theme.colors.detailText,
    flex: 1
  },
  titleSkeleton: {
    height: "2.5rem",
    width: "85%",
    margin: "1rem"
  },
  headerContainer: {
    display: "flex",
    flexDirection: "row",
    padding: "1rem 0",
    alignItems: "center",
  },
  adventureDetails: {
    display: "grid",
    gap: "1rem",
    gridTemplateColumns: "repeat(3, 1fr)",
    marginBottom: "1rem",
  },
  adventureDetailsKey: {
    fontSize: ".75rem"
  },
  adventureDetailsValue: {
    fontWeight: "700"
  },
  adventureItinerary: {
    paddingTop: "1rem",
    lineHeight: "1.6"
  },
}