/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
import { useGraphQLPersisted } from "../api";
import formatPhone from "../utils/formatPhone";


export default function Address({ _path}) {
  const { data, errors } = useGraphQLPersisted("wknd/team-location-by-location-path", _path );

  // Error State
  if (errors) {
      console.warn(`Error retrieving address for ${_path}`, errors);
    return null;
  }
  
  if (!data) {
    return (
      <div className="content detail-screen" style={styles.container}>
        <div style={styles.headerContainer}>
          <div className="loading-skeleton" style={styles.titleSkeleton}></div>
        </div>
      </div>
    )
}
    // Data Error State
  if (data && !data?.locationByPath?.item) {
    return null;
  }

    // Default Render view
    const { address, contactInfo } = data.locationByPath.item;
    return (
      <>
        <p style={styles.asideDescription}>{`${address.streetAddress}, ${address.city} ${address.state} ${address.zipCode}, ${address.country}`} </p>
        <p style={styles.asideDescription}> {formatPhone(contactInfo.phone)}</p> 
        <p style={styles.asideDescription}> {contactInfo.email}</p> 
      </>
    )
  }

const styles = {

  asideDescription:{
    paddingLeft: "20px",
    lineHeight: "1.6"
  },
  headerContainer: {
    display: "flex",
    flexDirection: "row",
    padding: "1rem 0",
    alignItems: "center",
  },
    titleSkeleton: {
    height: "2.5rem",
    width: "85%",
    margin: "1rem"
  },
}