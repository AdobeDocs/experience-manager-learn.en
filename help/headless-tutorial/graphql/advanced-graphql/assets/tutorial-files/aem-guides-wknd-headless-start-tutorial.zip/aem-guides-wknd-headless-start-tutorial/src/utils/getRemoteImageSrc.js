/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
export function getRemoteImageSrc(imagePath) {
  const { REACT_APP_PUBLIC_URI } = process.env;
  if (!imagePath) return false;
  if (imagePath.startsWith("http")) {
    imagePath = `${REACT_APP_PUBLIC_URI}${imagePath}`;
    if (imagePath && imagePath.includes("//content")) imagePath = imagePath.replace("//content", "/content");
  }
  return imagePath;
}