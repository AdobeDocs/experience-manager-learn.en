/*
Copyright 2022 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in
accordance with the terms of the Adobe license agreement accompanying
it.
*/
export const adventureListQuery = `{
  adventureList {
    items {
      _path
      adventureActivity
      adventureTitle
      adventurePrimaryImage {
        ...on ImageRef {
          _path
          mimeType
          width
          height
        }
      }
    }
  }
}`;

export const adventureDetailQuery = _path => `{
  adventureByPath (_path: "${_path}") {
    item {
      _path
      adventureTitle
      adventureActivity
      adventureType
      adventurePrice
      adventureTripLength
      adventureGroupSize
      adventureDifficulty
      adventurePrice
      adventurePrimaryImage {
        ... on ImageRef {
          _path
          mimeType
          width
          height
        }
      }
      adventureDescription {
        html
        json
      }
      adventureItinerary {
        html
        json
      }
    }
  }
}`;