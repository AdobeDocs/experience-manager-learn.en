/**
 * JavaScript supporting Styles may be re-used across multi Component Styles.
 *
 * For example:
 *    Many styles may require the Components Image (provided via an <img> element) to be set as the background-image.
 *    A single JavaScript function may be used to adjust the DOM for all styles that required this effect.
 *
 * JavaScript must react to the DOMNodeInserted event to handle style-switching in the Page Editor Authoring experience.
 * JavaScript must also run on DOM ready to handle the initial page load rendering (AEM Publish).
 * JavaScript must mark and check for elements as processed to avoid cyclic processing (ie. if the JavaScript inserts a DOM node of its own).
 */
jQuery(function ($) {
    "use strict;"

    /**
     * Method that injects an <img> element with the <img src... pointing to the linked page's Hero component's image.
     *
     * Similar to the CSS Style application, component HTML elements should be targed via the BEM class names (as they define the stable API)
     * and targeting "raw" elements (ex. "li", "a") should be avoided.
     */
    function applyComponentStyles() {

        $(".cmp-list--card").not("[data-styles-example-image-processed]").each(function () {
            var list = $(this).attr("data-styles-example-image-processed", true);

            // For each item in the list with a link...
            list.find(".cmp-list__item-link").each(function () {
                var anchor = $(this),
                    link,
                    imgSrc;

                if (anchor) {
                    link = anchor.attr("href");

                    if (link) {
                        // Derive the image src from the link's URL and using your knowledge of the underlying AEM Content Architecture.
                        imgSrc = link.substring(0, link.indexOf(".")) + "/_jcr_content/root/hero_image.img.jpeg";
                        // Create a new IMG element and add it before the Link Title
                        anchor.before($("<img>").addClass("cmp-list__item-image").attr("src", imgSrc));
                    }
                }
            });
        });
    }

    // Handle DOM Ready event
    applyComponentStyles();

    // Apply Styles when a component is inserted into the DOM (ie. during Authoring)
    $(".responsivegrid").bind("DOMNodeInserted", applyComponentStyles);
});