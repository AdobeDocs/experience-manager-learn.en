/*global jQuery: false, Granite: false*/
jQuery(function ($) {
    "use strict";

    function applyComponentStyles() {
        $(".cmp-contentfragment--featured-athlete").not("[data-cmp-featured-athlete-processed='true']").each(function () {
            var cf = $(this).attr("data-cmp-featured-athlete-processed", true),
                nationality = cf.find(".cmp-contentfragment__element--nationality .cmp-contentfragment__element-value").text().trim(),
                assetPath = cf.find(".cmp-contentfragment__element--pictureReference .cmp-contentfragment__element-value").text().trim();

            if (nationality) {
                var nationalityElement = $("<div class='cmp-contentfragment__nationality'>" + nationality + "</div>");
                cf.find(".cmp-contentfragment__element--fullName").before(nationalityElement);
            }

            console.log(assetPath);
            if (assetPath && assetPath.indexOf("/content/dam/") === 0) {
                var pictureElement = $("<img class='cmp-contentfragment__picture' src='" + assetPath + "'/>");
                cf.find(".cmp-contentfragment__element--fullName").before(pictureElement);
            }
        });
    }

    applyComponentStyles();

    $(".responsivegrid").bind("DOMNodeInserted", applyComponentStyles);
});