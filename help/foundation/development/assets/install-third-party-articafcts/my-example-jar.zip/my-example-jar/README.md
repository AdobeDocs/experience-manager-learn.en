# My Example Java Project

- It is a simple Java project that builds a jar file that contains a [MyHelloWorldService](./src/main/java/com/my/example/MyHelloWorldService.java) class.

- The [MyHelloWorldService](./src/main/java/com/my/example/MyHelloWorldService.java) class contains a `sayHello` method that returns a "Hello World!" string.

- However, the built jar is not released to any PUBLIC REPOSITORY like Maven Central. So, to use this jar in AEM Project like [WKND Site](https://github.com/adobe/aem-guides-wknd), you need to add it to the `all` package of the AEM project. For more details, see the tutorial [here](https://experienceleague.adobe.com/en/docs/experience-manager-learn/foundation/overview). 

- To build the project, run the following command:

    ```
    $ mvn clean package
    ```    

- The built jar can be found in the `target` directory, for example, `my-example-jar-1.0-SNAPSHOT.jar`.

