
@Version("1.0")
package com.example.services;

import org.osgi.annotation.versioning.Version;
