# My Example Bundle

- It is a simple OSGi project that builds a bundle that contains a [HelloWorldService](./src/main/java/com/example/services/HelloWorldService.java).

- The [HelloWorldService](./src/main/java/com/example/services/HelloWorldService.java) is registered as an OSGi service and can be accessed by other bundles.

- However, the bundle is not released to any PUBLIC REPOSITORY like Maven Central. So, to use this bundle in AEM Projects like [WKND Site](https://github.com/adobe/aem-guides-wknd), you need to add it to the `all` package of the AEM project. For more details, see the tutorial [here](https://experienceleague.adobe.com/en/docs/experience-manager-learn/foundation/overview). 

- To build the project, run the following command:

    ```
    $ mvn clean package
    ```    

- The built bundle can be found in the `target` directory, for example, `my-example-bundle-1.0-SNAPSHOT.jar`

- The bundle exports the ```com.example.services``` package, see [POM](./pom.xml#L33-L37) file.

- The project has been created using the following command:

    ```
    $ mvn archetype:generate \
    -DarchetypeGroupId=org.apache.sling \
    -DarchetypeArtifactId=sling-bundle-archetype \
    -DarchetypeVersion=1.0.6 \
    -DgroupId=com.example \
    -DartifactId=my-example-bundle \
    -Dversion=1.0-SNAPSHOT
    ```  
